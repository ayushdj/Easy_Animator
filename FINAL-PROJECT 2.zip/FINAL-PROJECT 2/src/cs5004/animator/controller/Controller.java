package cs5004.animator.controller;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.swing.*;

import cs5004.animator.model.EasyAnimatorModel;
import cs5004.animator.model.EasyAnimatorModelImpl;
import cs5004.animator.model.IShape;
import cs5004.animator.util.AnimationBuilder;
import cs5004.animator.util.AnimationReader;
import cs5004.animator.view.CompositeFrame;
import cs5004.animator.view.CompositeView;
import cs5004.animator.view.IView;
import cs5004.animator.view.SvgView;
import cs5004.animator.view.TextView;
import cs5004.animator.view.VisualView;

public class Controller implements IController {

  private IView view;
  private EasyAnimatorModel model;
  private Timer timer;
  private double speed;
  private double tick;
  StartListener startButton;
  private boolean flag = false;

  final JTextArea txtArea=new JTextArea(0,0);

  public Controller(IView view, EasyAnimatorModel model) {


    if(view.getViewType().equalsIgnoreCase("playback")) {
      this.view = view;
      this.model = model;
      this.speed = model.getAnimationSpeed();
      this.tick = 0;

      startButton = new StartListener();
      timer = new Timer((int) (1000/this.speed), startButton);
      this.view.addStartListener(startButton);

      ResumeListener resumeButton = new ResumeListener();
      this.view.addResumeListener(resumeButton);

      RestartListener restartButton = new RestartListener();
      this.view.addRestartListener(restartButton);

      PauseListener pauseButton = new PauseListener();
      this.view.addPauseListener(pauseButton);

      LoopListener loopButton = new LoopListener();
      this.view.addLoopListener(loopButton);

      SpeedUpListener speedUpButton = new SpeedUpListener();
      this.view.addSpeedUpListener(speedUpButton);

      SlowDownListener slowDownButton = new SlowDownListener();
      this.view.addSlowDownListener(slowDownButton);

      this.view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + (int)speed + "x");

      OpenNewFile newFile = new OpenNewFile();
      this.view.addMenuItemListener(newFile);
    } else {
      this.view = view;
      this.model = model;
      this.speed = model.getAnimationSpeed();
      this.tick = 0;
    }

  }

  class StartListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //make the border green
      //view.getCompositeFrame().getStartButton().setBorder(BorderFactory.createLineBorder(Color.GREEN, 3, true));
      view.getCompositeFrame().getStartButton().setText("Start: Running");
      timer.start();
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;

      if(tick == model.getEndTime() && !flag) {
        timer.stop();
      }
      else if (tick == model.getEndTime() && flag) {
        tick = 0;
        timer.restart();
        mutatedShapes = model.getShapesAtTimeStamp(tick);
        view.getCompositeFrame().currentView(mutatedShapes);
        tick++;
      }

    }
  }

  class PauseListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //timer.setDelay(10000);
      view.getCompositeFrame().getStartButton().setText("Start");
      view.getCompositeFrame().getPauseButton().setText("Pause: Paused");
      timer.stop();
      //List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      //view.getCompositeFrame().currentView(mutatedShapes);
    }
  }
  
  class ResumeListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //timer.setDelay(0);
      view.getCompositeFrame().getStartButton().setText("Start: Running");
      view.getCompositeFrame().getPauseButton().setText("Pause");
      timer.start();
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;

    }
  }

  class RestartListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      view.getCompositeFrame().getStartButton().setText("Start: Running");
      view.getCompositeFrame().getPauseButton().setText("Pause");
      tick = 0;
      timer.restart();
      speed = 1;
      timer.setDelay((int) (1000/speed));
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;
      view.getCompositeFrame().getSpeedUpButton().setText("Speed Up");
      view.getCompositeFrame().getSlowDownButton().setText("Slow Down");
      view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + speed);
    }
  }

  class LoopListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      if(!flag) {
        flag = true;
        view.getCompositeFrame().getLoopButton().setText("Loop: On");
      }
      else if(flag) {
        flag = false;
        view.getCompositeFrame().getLoopButton().setText("Loop: Off");
      }
      System.out.println(flag);
    }
  }

  class SpeedUpListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      speed = speed * 2;
      timer.setDelay((int) (1000/speed));
      view.getCompositeFrame().getSpeedUpButton().setText("Speed Up: " + (int)speed*2 + "x");
      view.getCompositeFrame().getSlowDownButton().setText("Slow Down");
      view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + (int)speed);
    }
  }

  class SlowDownListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      speed = speed / 2;
      if (speed < 1) {
        speed = 1;
      }
      view.getCompositeFrame().getSpeedUpButton().setText("Speed Up");
      view.getCompositeFrame().getSlowDownButton().setText("Slow Down: " + (int)speed/2 + "x");
      view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + (int)speed);
      timer.setDelay((int) (1000/speed));
    }
  }

  class OpenNewFile implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {

      FileDialog fd = new FileDialog(view.getCompositeFrame(), "select File",FileDialog.LOAD);
      fd.show();
      if (fd.getFile()!=null)
      {
        String filename = fd.getFile();
        System.out.println(filename);
        EasyAnimatorModel model2 = new EasyAnimatorModelImpl();
        AnimationBuilder<EasyAnimatorModel> builder = new
                EasyAnimatorModelImpl.BobTheBuilder(model2);
        //Readable
        String filePath = new File("").getAbsolutePath();
        Readable readable = null;
        try {
          readable = new FileReader(filePath + "/" + filename);
        } catch (FileNotFoundException fileNotFoundException) {
          fileNotFoundException.printStackTrace();
        }
        //Parse File
        AnimationReader.parseFile(readable, builder);
        view.getCompositeFrame().setTitle(filename);
        CompositeView viewType = new CompositeView(model2);
        new Controller(viewType, model2);

        BufferedReader d;
        StringBuffer sb = new StringBuffer();
        try
        {
          d = new BufferedReader(new FileReader(filename));
          String line;
          while((line=d.readLine())!=null)
            sb.append(line + "\n");
          txtArea.setText(sb.toString());
          d.close();
        }
        catch(FileNotFoundException fe)
        {
          System.out.println("File not Found");
        }
        catch(IOException ioe){}
      }
      txtArea.requestFocus();

    }
  }

  public void go() throws IOException {

    if(view.getViewType().equalsIgnoreCase("text")) {
      playTextView();
    } else if (view.getViewType().equalsIgnoreCase("svg")) {
      playSVGView();
    } else if (view.getViewType().equalsIgnoreCase("visual")) {
      playVisualView();
    }
  }

/*
  public void go(String viewType, String outputFile, double speed) {
      try {
        if (viewType.equals("svg") && (outputFile == null || outputFile.isEmpty())) {
          System.out.println(new SvgView(model, speed).showView());
        } else if (viewType.equals("svg")) {
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
          writer.write(new SvgView(model, speed).showView());
          writer.close();
        } else if (viewType.equals("text")) {
          System.out.println(new TextView((model)).showView());
        } else if (viewType.equals("visual")) {
          double tick = 0;
          IView obj = new VisualView(model);
          while (tick <= model.getEndTime()) {
            List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
            obj.getFrame().currentView(mutatedShapes);
            // tick corresponds to frames per second
            tick++;
            try {
              Thread.sleep((long) ((long) 100 / speed));
            } catch (InterruptedException ex) {
              Thread.currentThread().interrupt();
            }
          }
        } else if (viewType.equals("playback")) {
          this.speed = speed;

        }
      } catch (NullPointerException e) {
        JOptionPane.showMessageDialog(null, "Invalid view type", "View Error", JOptionPane.ERROR_MESSAGE);
      } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
      }
    }

 */

    private void playTextView() {
      System.out.println(view.showView());
    }

    private void playSVGView() throws IOException {
      if(this.view.getOutputFile().equalsIgnoreCase("")) {
        System.out.println(this.view.showView());
      } else {
        BufferedWriter writer = new BufferedWriter(new FileWriter(this.view.getOutputFile()));
        writer.write(this.view.showView());
        writer.close();
      }

    }

    private void playVisualView() {

      while (tick <= model.getEndTime()) {

        List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
        this.view.getFrame().currentView(mutatedShapes);
        // tick corresponds to frames per second
        tick++;

        try {
        Thread.sleep((long) ((long) 100 / speed));
        } catch (InterruptedException ex) {
          Thread.currentThread().interrupt();
        }
      }

    }


    public void playCompositeView() {
      double tick = 0;
      //IView obj = new VisualView(model);
      while (tick <= model.getEndTime()) {

        List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
        this.view.getCompositeFrame().currentView(mutatedShapes);
        // tick corresponds to frames per second
        tick++;

        //try {
          // speed
          //Thread.sleep((long) ((long) 100 / speed));
        //} catch (InterruptedException ex) {
        //  Thread.currentThread().interrupt();
        //}
      }
    }
    public IView getView() {
        return this.view;
    }

}
