package cs5004.animator.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyEvent;
import java.util.List;

import javax.swing.*;

import cs5004.animator.model.IShape;

public class CompositeFrame extends JFrame {


  private JButton start;
  private JButton pause;
  private JButton resume;
  private JButton restart;
  private JButton loop;
  private JButton speedUp;
  private JButton slowDown;
  private SwingPanel animationPanel;
  private JPanel buttonsPanel;
  private JPanel speedPanel;
  private JTextField textSpeed;
  private JMenuItem exitItem;

  JMenuBar menuBar;
  JMenu fileOption;
  JMenu submenuSave;
  JMenu submenuExit;
  JMenu submenuLoadNew;
  JMenu addShape;
  JMenu removeShape;
  JMenu submenuAddRect;
  JMenu submenuAddOval;
  JMenu submenuRemoveRect;
  JMenu submenuRemoveOval;
  JMenuItem menuItem;


  public CompositeFrame(int x, int y, int width, int height, List<IShape> listOfMutatedShapes) {
    super("Our Grand Animation");
    //this ensures that the Java Swing window closes when we click on the red X at top left of window
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    BorderLayout newBorder = new BorderLayout();
    this.setLayout(newBorder);
    this.setLocation(x, y);
    // this sets the size of the frame to 1000 x 1000
    this.setSize(width, height);


    // we are initializing these buttons here
    start = new JButton("Start");
    pause = new JButton("Pause");
    resume = new JButton("Resume");
    restart = new JButton("Restart");
    loop = new JButton("Loop: Off");
    speedUp = new JButton("Speed Up");
    slowDown = new JButton("Slow Down");
    textSpeed = new JTextField();
    textSpeed.setEditable(false);
    // this is a JPanel that takes care of the animation of shapes.
    this.animationPanel = new SwingPanel(listOfMutatedShapes);
    this.add(this.animationPanel, BorderLayout.CENTER);

    // Declaring a vertical scroll bar.
    JScrollBar verticalScrollBar = new JScrollBar(JScrollBar.VERTICAL, 0, 100, -200, 200);

    /**
     * This class is an adjustment listener for the vertical scroll bar. It allows us to offset
     * the panel by a certain distance, based on how much we scroll in the vertical direction.
     */
    class VerticalAdjustmentListener implements AdjustmentListener {
      @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {
        setPanelOffSetY(e.getValue());
      }
    }

    // Declaring the horizontal scroll bar.
    JScrollBar horizontalScrollBar = new JScrollBar(JScrollBar.HORIZONTAL, 0, 100, -200, 200);

    /**
     * This class is an adjustment listener for the horizontal scroll bar. It allows us to offset
     * the panel by a certain distance, based on how much we scroll in the horizontal direction.
     */
    class HorizontalAdjustmentListener implements AdjustmentListener {
      @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {
        setPanelOffSetX(e.getValue());
      }
    }

    // Here we are adding an adjustment Listener to the vertical and horizontal scroll
    // bars.
    verticalScrollBar.addAdjustmentListener(new VerticalAdjustmentListener());
    horizontalScrollBar.addAdjustmentListener(new HorizontalAdjustmentListener());

    // Adding the vertical and horizontal scroll bars to the frame.
    this.getContentPane().add(verticalScrollBar, BorderLayout.EAST);
    this.getContentPane().add(horizontalScrollBar, BorderLayout.SOUTH);

    //Add current speed to panel
    speedPanel = new JPanel();
    speedPanel.add(textSpeed);
    this.speedPanel.setVisible(true);

    // this panel is responsible for holding all the buttons
    buttonsPanel = new JPanel();
    buttonsPanel.add(start);
    buttonsPanel.add(pause);
    buttonsPanel.add(resume);
    buttonsPanel.add(restart);
    buttonsPanel.add(loop);
    buttonsPanel.add(speedUp);
    buttonsPanel.add(slowDown);

    //initializing a menu bar
    menuBar = new JMenuBar();

    //adding the File option
    fileOption = new JMenu("File");
    fileOption.setMnemonic(KeyEvent.VK_A);
    fileOption.getAccessibleContext().setAccessibleDescription(
            "File Options: Save, Exit, Load new File");

    addShape = new JMenu("Add-Shape");
    addShape.setMnemonic(KeyEvent.VK_A);
    addShape.getAccessibleContext().setAccessibleDescription(
            "Gives user ability to add new shape to animation");

    removeShape = new JMenu("Remove-Shape");
    removeShape.setMnemonic(KeyEvent.VK_A);
    removeShape.getAccessibleContext().setAccessibleDescription(
            "Gives user ability to remove shape from animation");
    menuBar.add(fileOption);
    menuBar.add(addShape);
    menuBar.add(removeShape);

    //submenu  "Save" in File Option
    fileOption.addSeparator();
    submenuSave = new JMenu("Save File");
    submenuSave.setMnemonic(KeyEvent.VK_S);

    //menu items for save file
    menuItem = new JMenuItem("Text File");
    menuItem.setAccelerator(KeyStroke.getKeyStroke(
            KeyEvent.VK_2, ActionEvent.ALT_MASK));

    submenuSave.add(menuItem);
    menuItem = new JMenuItem("SVG File");
    menuItem.setAccelerator(KeyStroke.getKeyStroke(
            KeyEvent.VK_2, ActionEvent.ALT_MASK));

    submenuSave.add(menuItem);

    //submenuItem  "Exit" in File Option
    exitItem = new JMenuItem(new AbstractAction("Exit Program") {
      @Override
      public void actionPerformed(ActionEvent e) {
        System.exit(NORMAL);
      }
    });

    //submenu  "Load New" in File Option
    submenuLoadNew = new JMenu("Load New File");
    submenuLoadNew.setMnemonic(KeyEvent.VK_S);

    //menu items for the Load New sub menu
    menuItem = new JMenuItem("Hanoi.txt");
    menuItem.setAccelerator(KeyStroke.getKeyStroke(
            KeyEvent.VK_2, ActionEvent.ALT_MASK));
    submenuLoadNew.add(menuItem);

    menuItem = new JMenuItem("big-bang-big-crunch.txt");
    submenuLoadNew.add(menuItem);

    //adding all the submenu items of File to the File option
    fileOption.add(submenuSave);
    fileOption.add(submenuLoadNew);
    fileOption.add(exitItem);

    //adding the menu bar to the frame
    this.setJMenuBar(menuBar);

    JPanel topPanel = new JPanel();
    topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.PAGE_AXIS));
    topPanel.add(this.buttonsPanel);
    topPanel.add(this.speedPanel);
    this.getContentPane().add(topPanel, BorderLayout.NORTH);

    pack();
    this.setSize(width, height);
    this.setLocation(x, y);
    this.animationPanel.setVisible(true);
    this.buttonsPanel.setVisible(true);
    this.setVisible(true);
  }

  public JButton getStartButton() {
    return this.start;
  }

  public JButton getPauseButton() {
    return this.pause;
  }

  public JButton getResumeButton() {
    return this.resume;
  }

  public JButton getRestartButton() {
    return this.restart;
  }

  public JButton getLoopButton() {
    return this.loop;
  }

  public JButton getSpeedUpButton() {
    return this.speedUp;
  }

  public JButton getSlowDownButton() {
    return this.slowDown;
  }

  public JTextField getTextSpeed() {return textSpeed;}

  public JMenuItem getMenuItem() {
    return this.menuItem;
  }

  /**
   * This method is a getter for the panel.
   *
   * @return The panel in the current frame.
   */
  public SwingPanel getPanel() {
    return this.animationPanel;
  }

  /**
   * This method updates the current view by setting the panel to the new list of mutated shapes,
   * and then calls the repaint method.
   *
   * @param listOfMutatedShapes The list of mutated shapes that was returned by the
   *                            getShapesAtTimeStamp, method in the model.
   */
  public void currentView(List<IShape> listOfMutatedShapes) {
    this.revalidate();
    this.animationPanel.setModel((listOfMutatedShapes));
    this.repaint();
  }

  /**
   * This method sets the panel offset for the y direction.
   *
   * @param value The amount by which we want to offset the panel in the y direction.
   */
  private void setPanelOffSetY(int value) {
    this.animationPanel.setPanelOffSetY(value);
  }

  /**
   * This method sets the panel offset for the x direction.
   *
   * @param value The amount by which we want the offset the panel in the x direction.
   */
  private void setPanelOffSetX(int value) {
    this.animationPanel.setPanelOffSetX(value);
  }


}
