package cs5004.animator.controller;

import cs5004.animator.model.EasyAnimatorModel;
import cs5004.animator.view.IView;

public class Controller implement ActionListener, KeyListener {

  EasyAnimatorModel model;
  IView view;


}
