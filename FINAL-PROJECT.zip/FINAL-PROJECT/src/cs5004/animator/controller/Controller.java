package cs5004.animator.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;

import javax.swing.*;

import cs5004.animator.model.EasyAnimatorModel;
import cs5004.animator.model.IShape;
import cs5004.animator.view.CompositeView;
import cs5004.animator.view.IView;
import cs5004.animator.view.SvgView;
import cs5004.animator.view.TextView;
import cs5004.animator.view.VisualView;

public class Controller {

  private CompositeView view;
  private EasyAnimatorModel model;
  private Timer timer;
  private double speed;
  private double tick;

  public Controller(CompositeView view, EasyAnimatorModel model) {

    this.view = view;
    this.model = model;
    this.speed = 1;
    this.tick = 0;

    StartListener startButton = new StartListener();
    timer = new Timer(50, startButton);
    this.view.addStartListener(startButton);

    this.view.addStopListener(new StopListener());
    this.view.addResumeListener(new ResumeListener());

    RestartListener restart = new RestartListener();
    this.view.addRestartListener(restart);
    this.view.addPauseListener(new PauseListener());
    this.view.addLoopListener(new LoopListener());
    this.view.addSpeedUpListener(new SpeedUpListener());
    this.view.addSlowDownListener(new SlowDownListener());

  }

  class StartListener implements ActionListener {


    @Override
    public void actionPerformed(ActionEvent e) {
      timer.start();
      System.out.println(timer.isRepeats());
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;

    }
  }

  class PauseListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //timer.setDelay(10000);
      timer.stop();
      //List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      //view.getCompositeFrame().currentView(mutatedShapes);
    }
  }

  class ResumeListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //timer.setDelay(0);
      timer.start();
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;

    }
  }

  class RestartListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      tick = 0;
      timer.restart();
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;

    }
  }

  class LoopListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //timer.setRepeats(false);
      //tick = 0;

      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;
    }
  }


  public void go(String viewType, String outputFile, double speed) {
      try {
        if (viewType.equals("svg") && (outputFile == null || outputFile.isEmpty())) {
          System.out.println(new SvgView(model, speed).showView());
        } else if (viewType.equals("svg")) {
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
          writer.write(new SvgView(model, speed).showView());
          writer.close();
        } else if (viewType.equals("text")) {
          System.out.println(new TextView((model)).showView());
        } else if (viewType.equals("visual")) {
          double tick = 0;
          IView obj = new VisualView(model);
          while (tick <= model.getEndTime()) {
            List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
            obj.getFrame().currentView(mutatedShapes);
            // tick corresponds to frames per second
            tick++;
            //try {
              // speed
             // Thread.sleep((long) ((long) 100 / speed));
            //} catch (InterruptedException ex) {
             // Thread.currentThread().interrupt();
            //}
          }
        } else if (viewType.equals("playback")) {
          this.speed = speed;

        }
      } catch (NullPointerException e) {
        JOptionPane.showMessageDialog(null, "Invalid view type", "View Error", JOptionPane.ERROR_MESSAGE);
      } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
      }
    }

    public void playCompositeView() {
      double tick = 0;
      //IView obj = new VisualView(model);
      while (tick <= model.getEndTime()) {

        List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
        this.view.getCompositeFrame().currentView(mutatedShapes);
        // tick corresponds to frames per second
        tick++;

        //try {
          // speed
          //Thread.sleep((long) ((long) 100 / speed));
        //} catch (InterruptedException ex) {
        //  Thread.currentThread().interrupt();
        //}
      }
    }
    public CompositeView getView() {
        return this.view;
    }
}
