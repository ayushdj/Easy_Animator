package cs5004.animator.controller;

public interface IController {
}
