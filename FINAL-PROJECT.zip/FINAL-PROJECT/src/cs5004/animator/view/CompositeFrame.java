package cs5004.animator.view;

import java.awt.BorderLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.util.List;

import javax.swing.*;

import cs5004.animator.model.IShape;

public class CompositeFrame extends JFrame {


  private JButton start;
  private JButton stop;
  private JButton pause;
  private JButton resume;
  private JButton restart;
  private JButton loop;
  private JButton speedUp;
  private JButton slowDown;
  private SwingPanel animationPanel;
  private JPanel buttonsPanel;


  public CompositeFrame(int x, int y, int width, int height, List<IShape> listOfMutatedShapes) {
    super("Our Grand Animation");
    //this ensures that the Java Swing window closes when we click on the red X at top left of window
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    BorderLayout newBorder = new BorderLayout();
    this.setLayout(newBorder);
    this.setLocation(x, y);
    // this sets the size of the frame to 1000 x 1000
    this.setSize(width, height);

    // we are initializing these buttons here
    start = new JButton("start");
    stop = new JButton("stop");
    pause = new JButton("pause");
    resume = new JButton("resume");
    restart = new JButton("restart");
    loop = new JButton("loop");
    speedUp = new JButton("speedUp");
    slowDown = new JButton("slowDown");

    // this is a JPanel that takes care of the animation of shapes.
    this.animationPanel = new SwingPanel(listOfMutatedShapes);
    this.add(this.animationPanel, BorderLayout.CENTER);

    // Declaring a vertical scroll bar.
    JScrollBar verticalScrollBar = new JScrollBar(JScrollBar.VERTICAL, 0, 100, -200, 200);

    /**
     * This class is an adjustment listener for the vertical scroll bar. It allows us to offset
     * the panel by a certain distance, based on how much we scroll in the vertical direction.
     */
    class VerticalAdjustmentListener implements AdjustmentListener {
      @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {
        setPanelOffSetY(e.getValue());
      }
    }

    // Declaring the horizontal scroll bar.
    JScrollBar horizontalScrollBar = new JScrollBar(JScrollBar.HORIZONTAL, 0, 100, -200, 200);

    /**
     * This class is an adjustment listener for the horizontal scroll bar. It allows us to offset
     * the panel by a certain distance, based on how much we scroll in the horizontal direction.
     */
    class HorizontalAdjustmentListener implements AdjustmentListener {
      @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {
        setPanelOffSetX(e.getValue());
      }
    }

    // Here we are adding an adjustment Listener to the vertical and horizontal scroll
    // bars.
    verticalScrollBar.addAdjustmentListener(new VerticalAdjustmentListener());
    horizontalScrollBar.addAdjustmentListener(new HorizontalAdjustmentListener());

    // Adding the vertical and horizontal scroll bars to the frame.
    this.getContentPane().add(verticalScrollBar, BorderLayout.EAST);
    this.getContentPane().add(horizontalScrollBar, BorderLayout.SOUTH);

    // this panel is responsible for holding all the buttons
    buttonsPanel = new JPanel();
    buttonsPanel.add(start);
    buttonsPanel.add(stop);
    buttonsPanel.add(pause);
    buttonsPanel.add(resume);
    buttonsPanel.add(restart);
    buttonsPanel.add(loop);
    buttonsPanel.add(speedUp);
    buttonsPanel.add(slowDown);

    this.add(buttonsPanel, BorderLayout.SOUTH);

    pack();
    this.setSize(width, height);
    this.setLocation(x, y);
    this.animationPanel.setVisible(true);
    this.buttonsPanel.setVisible(true);
    this.setVisible(true);
  }

  public JButton getStartButton() {
    return this.start;
  }

  public JButton getStopButton() {
    return this.stop;
  }

  public JButton getPauseButton() {
    return this.pause;
  }

  public JButton getResumeButton() {
    return this.resume;
  }

  public JButton getRestartButton() {
    return this.restart;
  }

  public JButton getLoopButton() {
    return this.loop;
  }

  public JButton getSpeedUpButton() {
    return this.speedUp;
  }

  public JButton getSlowDownButton() {
    return this.slowDown;
  }

  /**
   * This method is a getter for the panel.
   *
   * @return The panel in the current frame.
   */
  public SwingPanel getPanel() {
    return this.animationPanel;
  }

  /**
   * This method updates the current view by setting the panel to the new list of mutated shapes,
   * and then calls the repaint method.
   *
   * @param listOfMutatedShapes The list of mutated shapes that was returned by the
   *                            getShapesAtTimeStamp, method in the model.
   */
  public void currentView(List<IShape> listOfMutatedShapes) {
    this.revalidate();
    this.animationPanel.setModel((listOfMutatedShapes));
    this.repaint();
  }

  /**
   * This method sets the panel offset for the y direction.
   *
   * @param value The amount by which we want to offset the panel in the y direction.
   */
  private void setPanelOffSetY(int value) {
    this.animationPanel.setPanelOffSetY(value);
  }

  /**
   * This method sets the panel offset for the x direction.
   *
   * @param value The amount by which we want the offset the panel in the x direction.
   */
  private void setPanelOffSetX(int value) {
    this.animationPanel.setPanelOffSetX(value);
  }
}
