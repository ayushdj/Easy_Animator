package cs5004.animator.view;
import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.*;

import cs5004.animator.model.EasyAnimatorModel;

/**
 * This class represents a composite view. This is such that if a user type's in
 * "playback" in their command line arguments, an interactive GUI is generated. This
 * class represents that interactive GUI.
 */
public class CompositeView implements IView{

  private CompositeFrame frame;
  private EasyAnimatorModel model;

  /**
   * Generates a composite view instance.
   *
   * @param model The model whose data structures have been populated using the builder.
   */
  public CompositeView(EasyAnimatorModel model){
    this.model = model;
    this.frame = new CompositeFrame(model.getX(), model.getY(),
            model.getCanvasWidth(), model.getCanvasHeight(), model.getShapes());
  }


  /**
   * We are adding
   * @param listenForStart
   */
  public void addStartListener(ActionListener listenForStart) {

    //this.frame.getStartButton().setBorder(BorderFactory.createLineBorder(Color.green));

    this.frame.getStartButton().addActionListener(listenForStart);

  }

  public void addPauseListener(ActionListener listenForStart) {

    this.frame.getPauseButton().addActionListener(listenForStart);

  }
  public void addStopListener(ActionListener listenForStart) {

    this.frame.getStopButton().addActionListener(listenForStart);

  }

  public void addRestartListener(ActionListener listenForStart) {

    this.frame.getRestartButton().addActionListener(listenForStart);

  }

  public void addSpeedUpListener(ActionListener listenForStart) {

    this.frame.getSpeedUpButton().addActionListener(listenForStart);

  }

  public void addSlowDownListener(ActionListener listenForStart) {

    this.frame.getSlowDownButton().addActionListener(listenForStart);

  }

  public void addLoopListener(ActionListener listenForStart) {

    this.frame.getLoopButton().addActionListener(listenForStart);

  }

  public void addResumeListener(ActionListener listenForStart) {

    this.frame.getResumeButton().addActionListener(listenForStart);

  }


  @Override
  public String getViewType() {
    return "playback";
  }

  @Override
  public String showView() {
    return null;
  }

  @Override
  public SwingFrame getFrame() {
    return null;
  }

  public CompositeFrame getCompositeFrame() {
    return this.frame;
  }
}
