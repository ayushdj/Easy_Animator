package cs5004.animator.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

import cs5004.animator.model.IShape;

/**
 * This class represents a composite view that represents represents
 * buttons in addition
 */
public class CompositeView extends JFrame implements IView {

  private VisualView visualView;
  private JButton start;
  private JButton pause;
  private JButton resume;
  private JButton restart;
  private JButton loop;
  private JButton changeSpeed;
  private JPanel existingView;
  private JTextField input;

  /**
   * Creates a CompositeView object.
   */
  public CompositeView(VisualView visualView) {

    this.setSize(1000, 1000);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    this.setLayout(new FlowLayout());

    this.input = new JTextField(20);
    this.add(input);
    this.start = new JButton("Start");
    start.setActionCommand("Start Button");
    this.add(start);

    this.pause = new JButton("Pause");
    pause.setActionCommand("Pause Button");
    this.add(pause);

    this.resume = new JButton("Resume");
    resume.setActionCommand("Resume Button");
    this.add(resume);

    this.restart = new JButton("Restart");
    restart.setActionCommand("Restart Button");
    this.add(restart);

    this.loop = new JButton("Loop Playback");
    loop.setActionCommand("Loop Playback Button");
    this.add(loop);

    this.changeSpeed = new JButton("Change Speed");
    changeSpeed.setActionCommand("Change Speed Button");
    this.add(changeSpeed);
    this.visualView = visualView;

    pack();
    this.setVisible(true);

  }

  @Override
  public String getTypeOfView() {
    return null;
  }

  @Override
  public String showView() {
    return null;
  }

  @Override
  public SwingFrame getFrame() {
    return null;
  }
}
