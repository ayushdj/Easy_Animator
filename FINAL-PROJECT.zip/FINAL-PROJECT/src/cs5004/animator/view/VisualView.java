package cs5004.animator.view;

import cs5004.animator.model.EasyAnimatorModel;

/**
 * This class represents a visual view.
 */
public class VisualView implements IView {

  SwingFrame frame;
  EasyAnimatorModel model;

  /**
   * This method constructs a visual view object.
   *
   * @param model The model from our builder.
   */
  public VisualView(EasyAnimatorModel model) {
    if(model == null) {
      throw new IllegalArgumentException("The model you passed in is null");
    }
    this.model = model;
    this.frame = new SwingFrame(model.getX(), model.getY(),
            model.getCanvasWidth(), model.getCanvasHeight(), model.getShapes());
  }

  @Override
  public String getType() {
    return "visual";
  }

  @Override
  public String showView() {
    throw new UnsupportedOperationException("Cannot show the view in text format");
  }

  /**
   * A getter method to retrieve the frame.
   *
   * @return The frame of the animaion.
   */
  public SwingFrame getFrame() {
    return this.frame;
  }

  /**
   * A getter method to retrieve the model.
   *
   * @return The model.
   */
  public EasyAnimatorModel getModel() {
    return this.model;
  }
}
