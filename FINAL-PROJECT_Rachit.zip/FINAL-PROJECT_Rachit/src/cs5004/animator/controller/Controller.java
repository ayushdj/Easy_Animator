package cs5004.animator.controller;

import cs5004.animator.view.ViewFactory;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.swing.*;

import cs5004.animator.model.EasyAnimatorModel;
import cs5004.animator.model.EasyAnimatorModelImpl;
import cs5004.animator.model.IShape;
import cs5004.animator.model.Oval;
import cs5004.animator.model.Rectangle;
import cs5004.animator.util.AnimationBuilder;
import cs5004.animator.util.AnimationReader;
import cs5004.animator.view.CompositeView;
import cs5004.animator.view.IView;

/**
 * This class represents the Controller of the entire application. It takes in a view and a model
 * and based on that view and model, it creates the required output.
 */
public class Controller implements IController {

  private IView view;
  private EasyAnimatorModel model;
  private Timer timer;
  private double speed;
  private double tick;
  StartListener startButton;
  private boolean flag = false;
  static int svgCount = 0; //for saved output svg file (extra credit)
  static int textCount = 0; //for saved output txt file (extra credit)

  final JTextArea txtArea=new JTextArea(0,0);

  public Controller(IView view, EasyAnimatorModel model) {


    if(view.getViewType().equalsIgnoreCase("playback")) {
      this.view = view;
      this.model = model;
      this.speed = model.getAnimationSpeed();
      this.tick = 0;

      startButton = new StartListener();
      timer = new Timer((int) (1000/this.speed), startButton);
      this.view.addStartListener(startButton);

      ResumeListener resumeButton = new ResumeListener();
      this.view.addResumeListener(resumeButton);

      RestartListener restartButton = new RestartListener();
      this.view.addRestartListener(restartButton);

      PauseListener pauseButton = new PauseListener();
      this.view.addPauseListener(pauseButton);

      LoopListener loopButton = new LoopListener();
      this.view.addLoopListener(loopButton);

      SpeedUpListener speedUpButton = new SpeedUpListener();
      this.view.addSpeedUpListener(speedUpButton);

      SlowDownListener slowDownButton = new SlowDownListener();
      this.view.addSlowDownListener(slowDownButton);

      this.view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + (int)speed + "x");

      OpenNewFile newFile = new OpenNewFile();
      this.view.addMenuItemListener(newFile);

      AddShapeOption addNewShape = new AddShapeOption();
      this.view.addShapeListener(addNewShape);

      RemoveShapeListener removeShapeListener = new RemoveShapeListener();
      this.view.addRemoveShapeListener(removeShapeListener);

      SaveTextListener saveTextListener = new SaveTextListener();
      this.view.addSaveTextListener(saveTextListener);

      SaveSvgListener saveSvgListener = new SaveSvgListener();
      this.view.addSaveSvgListener(saveSvgListener);

    } else {
      this.view = view;
      this.model = model;
      this.speed = model.getAnimationSpeed();
      this.tick = 0;
    }

  }

  private class StartListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //make the border green
      //view.getCompositeFrame().getStartButton().setBorder(BorderFactory.createLineBorder(Color.GREEN, 3, true));
      view.getCompositeFrame().getStartButton().setText("Start: Running");
      timer.start();
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;

      if(tick == model.getEndTime() && !flag) {
        timer.stop();
      }
      else if (tick == model.getEndTime() && flag) {
        tick = 0;
        timer.restart();
        mutatedShapes = model.getShapesAtTimeStamp(tick);
        view.getCompositeFrame().currentView(mutatedShapes);
        tick++;
      }

    }
  }

  private class PauseListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //timer.setDelay(10000);
      view.getCompositeFrame().getStartButton().setText("Start");
      view.getCompositeFrame().getPauseButton().setText("Pause: Paused");
      timer.stop();
      //List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      //view.getCompositeFrame().currentView(mutatedShapes);
    }
  }
  
  private class ResumeListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      //timer.setDelay(0);
      view.getCompositeFrame().getStartButton().setText("Start: Running");
      view.getCompositeFrame().getPauseButton().setText("Pause");
      timer.start();
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;

    }
  }

  private class RestartListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      view.getCompositeFrame().getStartButton().setText("Start: Running");
      view.getCompositeFrame().getPauseButton().setText("Pause");
      tick = 0;
      timer.restart();
      speed = 1;
      timer.setDelay((int) (1000/speed));
      List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
      view.getCompositeFrame().currentView(mutatedShapes);
      tick++;
      view.getCompositeFrame().getSpeedUpButton().setText("Speed Up");
      view.getCompositeFrame().getSlowDownButton().setText("Slow Down");
      view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + speed);
    }
  }

  private class LoopListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      if(!flag) {
        flag = true;
        view.getCompositeFrame().getLoopButton().setText("Loop: On");
      }
      else if(flag) {
        flag = false;
        view.getCompositeFrame().getLoopButton().setText("Loop: Off");
      }
      System.out.println(flag);
    }
  }

  private class SpeedUpListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      speed = speed * 2;
      timer.setDelay((int) (1000/speed));
      view.getCompositeFrame().getSpeedUpButton().setText("Speed Up: " + (int)speed*2 + "x");
      view.getCompositeFrame().getSlowDownButton().setText("Slow Down");
      view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + (int)speed);
    }
  }

  private class SlowDownListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
      speed = speed / 2;
      if (speed < 1) {
        speed = 1;
      }
      view.getCompositeFrame().getSpeedUpButton().setText("Speed Up");
      view.getCompositeFrame().getSlowDownButton().setText("Slow Down: " + (int)speed/2 + "x");
      view.getCompositeFrame().getTextSpeed().setText("Current Speed: " + (int)speed);
      timer.setDelay((int) (1000/speed));
    }
  }

  private class OpenNewFile implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {

      FileDialog fd = new FileDialog(view.getCompositeFrame(), "select File",FileDialog.LOAD);
      fd.show();
      if (fd.getFile()!=null) {
        String filename = fd.getFile();
        System.out.println(filename);
        EasyAnimatorModel model2 = new EasyAnimatorModelImpl();
        AnimationBuilder<EasyAnimatorModel> builder = new
            EasyAnimatorModelImpl.BobTheBuilder(model2);
        //Readable
        String filePath = new File("").getAbsolutePath();
        Readable readable = null;
        try {
          readable = new FileReader(filePath + "/" + filename);
        } catch (FileNotFoundException fileNotFoundException) {
          fileNotFoundException.printStackTrace();
        }
        //Parse File
        AnimationReader.parseFile(readable, builder);

        double speed2 = 1;
        model2.setAnimationSpeed(speed2);

        IView ourView = ViewFactory.getView(model2, "playback", "", speed2);
        //view = new CompositeView(model);
        new Controller(ourView, model2);

      }
    }
  }
  private class AddShapeOption implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {

      //view.getCompositeFrame().getAddShapePanel().setVisible(true);

      try {
      IShape newShape = null;
      JOptionPane.showConfirmDialog(null, view.getCompositeFrame().getAddShapePanel(), "Enter the following information to construct your Shape", 2);
      if (view.getCompositeFrame().getShapeType().equalsIgnoreCase("rectangle")) {
        newShape = new Rectangle(
                view.getCompositeFrame().getName(),
                view.getCompositeFrame().getShapeX(),
                view.getCompositeFrame().getShapeY(),
                view.getCompositeFrame().getShapeHeight(),
                view.getCompositeFrame().getShapeWidth(),
                new Color(view.getCompositeFrame().getShapeRed(), view.getCompositeFrame().getShapeGreen(), view.getCompositeFrame().getShapeBlue()),
                view.getCompositeFrame().getShapeAppear(),
                view.getCompositeFrame().getShapeDisappear());
      } else  if(view.getCompositeFrame().getShapeType().equalsIgnoreCase("oval")) {
        newShape = new Oval(
                view.getCompositeFrame().getName(),
                view.getCompositeFrame().getShapeX(),
                view.getCompositeFrame().getShapeY(),
                view.getCompositeFrame().getShapeHeight(),
                view.getCompositeFrame().getShapeWidth(),
                new Color(view.getCompositeFrame().getShapeRed(), view.getCompositeFrame().getShapeGreen(), view.getCompositeFrame().getShapeBlue()),
                view.getCompositeFrame().getShapeAppear(),
                view.getCompositeFrame().getShapeDisappear());
      } else if(!view.getCompositeFrame().getShapeType().equalsIgnoreCase("rectangle") || !view.getCompositeFrame().getShapeType().equalsIgnoreCase("oval")) {
        System.out.println("this is the wrong shape");
      }
      model.addShape(newShape);
      model.moveShape(newShape, 180, 200, 0, 50);
      } catch(Exception exception) {
        JOptionPane.showMessageDialog(null, exception.getMessage(),
                "Invalid input in trying to add shape", JOptionPane.ERROR_MESSAGE);
      }
/*
      String name = (String) JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Enter Shape Name:");
      String type = (String) JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Enter shape Type (rectangles or ovals only): ");
      double x = Double.parseDouble(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape x-coordinate: "));
      double y = Double.parseDouble(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape y-coordinate: "));
      double height = Double.parseDouble(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape height: "));
      double width = Double.parseDouble(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape width: "));
      int r = Integer.parseInt(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape's red color value (0-255)"));
      int g = Integer.parseInt(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape's green color value (0-255)"));
      int b = Integer.parseInt(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape's blue color value (0-255)"));
      double startTime = Double.parseDouble(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape's time appear: "));
      double endTime = Double.parseDouble(JOptionPane.showInputDialog(view.getCompositeFrame().getAddShapePanel(), "Shape's time disappear: "));

      IShape newShape = null;
      if (type.equalsIgnoreCase("rectangle")) {
         newShape = new Rectangle(name, x, y, height, width, new Color(r, g, b), startTime, endTime);
      } else  if(type.equalsIgnoreCase("oval")) {
         newShape = new Oval(name, x, y, height, width, new Color(r, g, b), startTime, endTime);
      } else if(!type.equalsIgnoreCase("rectangle") || !type.equalsIgnoreCase("oval")) {
        System.out.println("this is the wrong shape");
      }
      model.addShape(newShape);
      model.moveShape(newShape, 180, 200, 0, 50);

 */

    }
  }

  class SaveSvgListener implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e) {
      String fileName = "Custom_Saved_SVG_" + svgCount + ".svg";
      svgCount++;
      IView ourView = ViewFactory.getView(model, "svg", fileName, speed);
      try {
        new Controller(ourView, model).go();
      } catch (IOException ioException) {
        ioException.printStackTrace();
      }
    }
  }

  class SaveTextListener implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e) {
      String fileName = "Custom_Saved_Text_" + textCount + ".txt";
      textCount++;
      IView ourView = ViewFactory.getView(model, "text", "", speed);
      BufferedWriter writer;
      try {
        writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(ourView.showView());
        writer.close();
      } catch (IOException ioException) {
        ioException.printStackTrace();
      }
    }
  }

  class RemoveShapeListener implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e) {
      String result = (String)JOptionPane.showInputDialog(view.getCompositeFrame(), "Enter Name of Shape to Remove",
          "Remove Shape", JOptionPane.PLAIN_MESSAGE, null, null, "");
      try {
        if(!(result==null))
          model.removeShape(result);
      }
      catch(IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(null,
            "Shape Not Found!", "User Input Error.", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void go() throws IOException {

    if(view.getViewType().equalsIgnoreCase("text")) {
      playTextView();
    } else if (view.getViewType().equalsIgnoreCase("svg")) {
      playSVGView();
    } else if (view.getViewType().equalsIgnoreCase("visual")) {
      playVisualView();
    }
  }

/*
  public void go(String viewType, String outputFile, double speed) {
      try {
        if (viewType.equals("svg") && (outputFile == null || outputFile.isEmpty())) {
          System.out.println(new SvgView(model, speed).showView());
        } else if (viewType.equals("svg")) {
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
          writer.write(new SvgView(model, speed).showView());
          writer.close();
        } else if (viewType.equals("text")) {
          System.out.println(new TextView((model)).showView());
        } else if (viewType.equals("visual")) {
          double tick = 0;
          IView obj = new VisualView(model);
          while (tick <= model.getEndTime()) {
            List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
            obj.getFrame().currentView(mutatedShapes);
            // tick corresponds to frames per second
            tick++;
            try {
              Thread.sleep((long) ((long) 100 / speed));
            } catch (InterruptedException ex) {
              Thread.currentThread().interrupt();
            }
          }
        } else if (viewType.equals("playback")) {
          this.speed = speed;

        }
      } catch (NullPointerException e) {
        JOptionPane.showMessageDialog(null, "Invalid view type", "View Error", JOptionPane.ERROR_MESSAGE);
      } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
      }
    }

 */

    private void playTextView() {
      System.out.println(view.showView());
    }

    private void playSVGView() throws IOException {
      if(this.view.getOutputFile().equalsIgnoreCase("")) {
        System.out.println(this.view.showView());
      } else {
        BufferedWriter writer = new BufferedWriter(new FileWriter(this.view.getOutputFile()));
        writer.write(this.view.showView());
        writer.close();
      }

    }

    private void playVisualView() {

      while (tick <= model.getEndTime()) {

        List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
        this.view.getFrame().currentView(mutatedShapes);
        // tick corresponds to frames per second
        tick++;

        try {
        Thread.sleep((long) ((long) 100 / speed));
        } catch (InterruptedException ex) {
          Thread.currentThread().interrupt();
        }
      }

    }


    public void playCompositeView() {
      double tick = 0;
      //IView obj = new VisualView(model);
      while (tick <= model.getEndTime()) {

        List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
        this.view.getCompositeFrame().currentView(mutatedShapes);
        // tick corresponds to frames per second
        tick++;

        //try {
          // speed
          //Thread.sleep((long) ((long) 100 / speed));
        //} catch (InterruptedException ex) {
        //  Thread.currentThread().interrupt();
        //}
      }
    }
    public IView getView() {
        return this.view;
    }

}
