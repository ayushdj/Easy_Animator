package cs5004.animator.controller;

import java.io.IOException;

import cs5004.animator.view.IView;


public interface IController {

  void go() throws IOException;
  IView getView();
}
