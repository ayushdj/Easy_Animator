package cs5004.animator.view;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;
import javax.swing.*;

import cs5004.animator.model.EasyAnimatorModel;
import cs5004.animator.model.IShape;

/**
 * This class is a ViewFactory that decides what actions to take based on the view type that is
 * passed in from the EasyAnimator class.
 */
public class ViewFactory {

  /**
   * This method gets the view and generates the required view based on that.
   *
   * @param model The model with the populated data structures.
   * @param viewType The view type we get from the EasyAnimator class.
   * @param outputFile The name of the output file we want.
   * @param speed The speed of the animation.
   */
  public static IView getView(EasyAnimatorModel model, String viewType, String outputFile, double speed) {

    IView view = null;
    try {
      if (viewType.equals("svg") && (outputFile == null || outputFile.isEmpty())) {
        view = new SvgView(model, speed);
      } else if (viewType.equalsIgnoreCase("svg")) {
        view = new SvgView(model, speed, outputFile);
      } else if (viewType.equalsIgnoreCase("text")) {
        view = new TextView(model);
      } else if (viewType.equalsIgnoreCase("visual")) {
        view = new VisualView(model);
      } else if(viewType.equalsIgnoreCase("playback")) {
        view = new CompositeView(model);
      }

    } catch(Exception e) {
      System.out.println("There's something wrong");
    }
    return view;

    /*try {
      if (viewType.equals("svg") && (outputFile == null || outputFile.isEmpty())) {
        System.out.println(new SvgView(model, speed).showView());
      } else if (viewType.equals("svg")) {
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
        writer.write(new SvgView(model, speed).showView());
        writer.close();
      } else if (viewType.equals("text")) {
        System.out.println(new TextView((model)).showView());
      } else if (viewType.equals("visual")) {
        double tick = 0;
        IView obj = new VisualView(model);
        while (tick <= model.getEndTime()) {
          List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
          obj.getFrame().currentView(mutatedShapes);
          // tick corresponds to frames per second
          tick++;
          try {
            // speed
            Thread.sleep((long) ((long) 100 / speed));
          } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
          }
        }
      }
    } catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, "Invalid view type", "View Error", JOptionPane.ERROR_MESSAGE);

    } catch (IllegalArgumentException e) {
      JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
    }

     */
  }
}
