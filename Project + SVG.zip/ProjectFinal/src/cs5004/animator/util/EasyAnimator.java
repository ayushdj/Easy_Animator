package cs5004.animator.util;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;

import cs5004.easyanimator.model.EasyAnimatorModel;
import cs5004.easyanimator.model.EasyAnimatorModelImpl;

public class EasyAnimator {
  public static void main(String[] args) throws IOException {
    EasyAnimatorModel myModel = new EasyAnimatorModelImpl();
    String basePath = "C:\\Users\\Owner\\Desktop\\Project\\ProjectFinal\\src\\cs5004\\animator\\util\\";
    String in = "";
    String out = "";
    double speed = 0;
    String view = "";

    try {
      for (int i = 0; i < args.length; i+=2) {
        if (args[i].equalsIgnoreCase("-in")) {
          in = args[i + 1];
        }
        else if (args[i].equalsIgnoreCase("-out")) {
          out = args[i + 1];
        }
        else if (args[i].equalsIgnoreCase("-view")) {
          view = args[i + 1];
        }
        else if (args[i].equalsIgnoreCase("-speed")) {
          speed = Integer.parseInt(args[i + 1]);
        }
        else {
          throw new IllegalArgumentException("one of your arguments is not valid");
        }
      }
    } catch (IndexOutOfBoundsException e) {
      throw new IllegalArgumentException("arguments are not in pairs (i.e. one of your arguments"
              + " is missing");
    } catch (NumberFormatException e2) {
      throw new IllegalArgumentException("Speed is not an integer");
    } catch (Exception e) {
      throw new IllegalArgumentException("bruh are you gae");
    }
    view = "svg";
    out = "output.svg";
    speed = 0.05;
    AnimationBuilder<EasyAnimatorModel> builder = new EasyAnimatorModelImpl.BobTheBuilder(myModel);
    Readable readable = new FileReader(basePath + "buildings.txt");
    AnimationReader.parseFile(readable, builder);

    switch (view) {
      case "text":
        TextView.showView(myModel);
        break;
      case "svg":
        BufferedWriter writer = new BufferedWriter(new FileWriter(out));
        writer.write(SvgView.showView(myModel, speed));
        writer.close();
        //System.out.println(SvgView.showView(myModel, speed));
        break;
    }






  }
}
