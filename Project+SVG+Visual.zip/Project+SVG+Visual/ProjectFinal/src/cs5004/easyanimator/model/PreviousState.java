package cs5004.easyanimator.model;

public class PreviousState implements AnimationChanges{

  private double oldLength;
  private double oldWidth;
  private double newLength;
  private double newWidth;
  private double start;
  private double end;
  private final Transformations transformation;

  private IShape currentState;
  public PreviousState(double newLength, double newWidth, IShape shape, double start, double end) {

    this.oldLength = shape.getLength();
    this.oldWidth = shape.getWidth();
    this.newLength = newLength;
    this.newWidth = newWidth;
    this.start = start;
    this.end = end;
    this.transformation = Transformations.NO_CHANGE;

    this.currentState = shape;
  }

  @Override
  public IShape executeChange(IShape shape, double time) {
    return shape;
  }

  @Override
  public String stringForm(String key) {
    return null;
  }

  @Override
  public double getStart() {
    return 0;
  }

  @Override
  public double getEnd() {
    return 0;
  }

  @Override
  public Transformations getTransformation() {
    return null;
  }

  @Override
  public void tweening(double time) {

  }

  @Override
  public Object getOld() {
    return null;
  }

  @Override
  public Object getNew() {
    return null;
  }

  @Override
  public IShape getCurrentState() {
    return this.currentState;
  }
}
