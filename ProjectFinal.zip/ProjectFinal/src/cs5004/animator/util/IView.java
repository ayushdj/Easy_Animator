package cs5004.animator.util;

public interface IView {
}
