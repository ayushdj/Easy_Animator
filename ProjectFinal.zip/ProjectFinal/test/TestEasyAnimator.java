import org.junit.Before;
import org.junit.Test;

import java.awt.Color;

import cs5004.easyanimator.model.EasyAnimatorModelImpl;
import cs5004.easyanimator.model.IShape;
import cs5004.easyanimator.model.Rectangle;
import cs5004.easyanimator.model.EasyAnimatorModel;

import cs5004.easyanimator.model.Oval;

import static org.junit.Assert.assertEquals;

/** This class tests the EasyAnimatorModel class. */
public class TestEasyAnimator {

  IShape rectangle1;
  IShape square1;
  IShape circle1;
  IShape oval1;
  EasyAnimatorModel newAnimation;

  @Before
  public void setUp() {
    rectangle1 = new Rectangle("R1", 0, 0, 4, 7, new Color(200, 100, 60), 10, 100);
    square1 = new Rectangle("S1", -3, -3, 4, 4, new Color(0, 100, 170), 30, 70);
    circle1 = new Oval("C1", 5, 5, 4, 4, new Color(40, 150, 60), 0, 100);
    oval1 = new Oval("O1", 2, 3, 7, 3, new Color(1, 15, 10), 50, 120);
    newAnimation = new EasyAnimatorModelImpl();
  }

  /** Testing the case in which the shape added is null. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalAddShape1() {
    newAnimation.addShape(null);
  }

  /**
   * Testing the case in which we're adding a shape with the same key as another shape in the
   * hashmap.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalAddShape2() {
    newAnimation.addShape(rectangle1);
    IShape rectangle2 = new Rectangle("R1", 0, 1, 3, 1, new Color(50, 100, 255), 20, 30);
    newAnimation.addShape(rectangle2);
  }

  /** Testing a valid addShape method. */
  @Test
  public void testAddShape() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    assertEquals(
        "Shapes:\n"
            + "Name: R1\n"
            + "Type: rectangle\n"
            + "Min corner: (0.0,0.0), Width: 7.0, Height: 4.0, Color: (200.0,100.0,60.0)\n"
            + "Appears at t=10.0\n"
            + "Disappears at t=100.0\n"
            + "\n"
            + "Name: S1\n"
            + "Type: rectangle\n"
            + "Min corner: (-3.0,-3.0), Width: 4.0, Height: 4.0, Color: (0.0,100.0,170.0)\n"
            + "Appears at t=30.0\n"
            + "Disappears at t=70.0\n"
            + "\n"
            + "Name: C1\n"
            + "Type: oval\n"
            + "Min corner: (5.0,5.0), Width: 4.0, Height: 4.0, Color: (40.0,150.0,60.0)\n"
            + "Appears at t=0.0\n"
            + "Disappears at t=100.0\n"
            + "\n"
            + "Name: O1\n"
            + "Type: oval\n"
            + "Min corner: (2.0,3.0), Width: 3.0, Height: 7.0, Color: (1.0,15.0,10.0)\n"
            + "Appears at t=50.0\n"
            + "Disappears at t=120.0\n\n",
        newAnimation.toString());
  }

  // ===================================== REMOVE-SHAPE TESTS ====================================
  /** Testing the case in which we try to remove a null shape. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalRemoveShape1() {
    newAnimation.removeShape(null);
  }

  /** Testing the case in which we try to remove a shape that doesn't exist. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalRemoveShape2() {
    newAnimation.removeShape(rectangle1.getName());
  }

  /** Testing a valid remove shape. */
  @Test
  public void testLegalRemoveShape1() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.removeShape(rectangle1.getName());
    assertEquals(
        "Shapes:\n"
            + "Name: S1\n"
            + "Type: rectangle\n"
            + "Min corner: (-3.0,-3.0), Width: 4.0, Height: 4.0, Color: (0.0,100.0,170.0)\n"
            + "Appears at t=30.0\n"
            + "Disappears at t=70.0\n"
            + "\n"
            + "Name: C1\n"
            + "Type: oval\n"
            + "Min corner: (5.0,5.0), Width: 4.0, Height: 4.0, Color: (40.0,150.0,60.0)\n"
            + "Appears at t=0.0\n"
            + "Disappears at t=100.0\n"
            + "\n"
            + "Name: O1\n"
            + "Type: oval\n"
            + "Min corner: (2.0,3.0), Width: 3.0, Height: 7.0, Color: (1.0,15.0,10.0)\n"
            + "Appears at t=50.0\n"
            + "Disappears at t=120.0\n"
            + "\n",
        newAnimation.toString());
  }

  // ===================================== MOVE-SHAPE TESTS ====================================
  /** Testing the case in which the shape passed in is null. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape1() {
    newAnimation.moveShape(null, 0, 0, 4, 5);
  }

  /**
   * Testing the case in which the start time is less than the shape's timeAppear, but the end time
   * is less than the shape's timeDisappear.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape2() {
    newAnimation.moveShape(rectangle1, 4, 5, 5, 50);
  }

  /**
   * Testing the case in which the start time is greater than the timeAppear but the end time is
   * greater than the shape's timeDisappear.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape3() {
    newAnimation.moveShape(square1, 0, 0, 35, 75);
  }

  /**
   * Testing the case in which the start time is less than the timeAppear for the shape AND the end
   * time is greater than the shape's timeDisappear.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape4() {
    newAnimation.moveShape(oval1, 0, 0, 40, 130);
  }

  /** Testing the case in which the start time is greater than the end time. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape5() {
    newAnimation.moveShape(circle1, 0, 0, 50, 40);
  }

  /** Testing the case in which the start time is EQUAL to the end time. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape6() {
    newAnimation.moveShape(circle1, 0, 0, 50, 50);
  }

  /** Testing move shape with the newX and newY equal to the oldX and oldY. */
  @Test
  public void testIllegalMoveShape7() {
    newAnimation.moveShape(rectangle1, 0, 0, 31.8, 32);
    assertEquals(0.0, rectangle1.getX(), 0.001);
    assertEquals(0.0, rectangle1.getY(), 0.001);
  }

  /** Testing a legal moveShape. */
  @Test
  public void testLegalMoveShape() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.moveShape(rectangle1, 4, 8, 30, 60);
    assertEquals(4.0, rectangle1.getX(), 0.001);
    assertEquals(8.0, rectangle1.getY(), 0.001);

    newAnimation.moveShape(square1, 0, 0, 50, 60);
    assertEquals(0.0, square1.getX(), 0.001);
    assertEquals(0.0, square1.getY(), 0.001);

    newAnimation.moveShape(circle1, 0, 0, 20, 90);
    assertEquals(0.0, circle1.getX(), 0.001);
    assertEquals(0.0, circle1.getY(), 0.001);

    newAnimation.moveShape(oval1, 2, 2, 51, 100);
    assertEquals(2.0, oval1.getX(), 0.001);
    assertEquals(2.0, oval1.getY(), 0.001);
  }

  // =================================== CHANGE-COLOR TESTS ====================================

  /** Testing an illegal ColorChange where the shape passed in is null. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColor1() {
    newAnimation.changeColor(null, 0, 1, 2, 30, 50);
  }

  /**
   * Testing an illegal Color Change where the start is less than the time appear but the end is
   * valid.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColor3() {
    newAnimation.changeColor(rectangle1, 20, 30, 10, 5, 90);
  }

  /** Testing an illegal Color change when the start time is valid and the end time is invalid. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColor4() {
    newAnimation.changeColor(square1, 5, 50, 50, 35, 80);
  }

  /** Testing an illegal Color change when the start time is invalid AND the end time is invalid. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColor5() {
    newAnimation.changeColor(circle1, 2, 2, 2, -1, 110);
  }

  /** Testing the case where the new colors are the same as the old colors. */
  @Test
  public void testIllegalChangeColors6() {
    newAnimation.changeColor(oval1, 1, 15, 10, 60, 70);
    assertEquals(1, oval1.getColor().getRed());
    assertEquals(15, oval1.getColor().getGreen());
    assertEquals(10, oval1.getColor().getBlue());
  }

  /** Testing the case where the start time is greater than the end time. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColors7() {
    newAnimation.changeColor(rectangle1, 155, 155, 155, 30, 15);
  }

  /** Testing the case in which the start time is equal to the end time. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColors8() {
    newAnimation.changeColor(rectangle1, 155, 155, 155, 30, 30);
  }

  /** Testing negative RGB values. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColor9() {
    newAnimation.changeColor(square1, -20, -30, -40, 35, 40);
  }

  /** Testing RGB values greater than 255. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalChangeColor10() {
    newAnimation.changeColor(circle1, 256, 256, 256, 5, 6);
  }

  /** Testing a valid changeColor. */
  @Test
  public void testLegalChangeColor() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.changeColor(rectangle1, 155, 155, 155, 30, 32);
    assertEquals(155, rectangle1.getColor().getRed());
    assertEquals(155, rectangle1.getColor().getGreen());
    assertEquals(155, rectangle1.getColor().getBlue());

    newAnimation.changeColor(square1, 255, 255, 255, 50, 60);
    assertEquals(255, square1.getColor().getRed());
    assertEquals(255, square1.getColor().getGreen());
    assertEquals(255, square1.getColor().getBlue());

    newAnimation.changeColor(circle1, 0, 0, 0, 20, 50);
    assertEquals(0, circle1.getColor().getRed());
    assertEquals(0, circle1.getColor().getGreen());
    assertEquals(0, circle1.getColor().getBlue());

    newAnimation.changeColor(oval1, 2, 10, 15, 70, 90);
    assertEquals(2, oval1.getColor().getRed());
    assertEquals(10, oval1.getColor().getGreen());
    assertEquals(15, oval1.getColor().getBlue());
  }

  // ======================== SCALE-SHAPE (W/ SCALE FACTOR) TESTS ===============================
  /** This tests the case in which the shape is null. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape1_a() {
    newAnimation.scaleShape(null, 3, 50, 60);
  }

  /** This tests the case in which the scale factor is negative. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape2_a() {
    newAnimation.scaleShape(rectangle1, -1, 20, 80);
  }

  /**
   * This tests the case in which the scale factor is valid but the start time is invalid (the end
   * time is valid).
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape3_a() {
    newAnimation.scaleShape(square1, 2, 9, 50);
  }

  /**
   * This tests the case in which the scale factor is valid, the start time is valid and the end
   * time is invalid.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape4_a() {
    newAnimation.scaleShape(circle1, 7.5, 11, 150);
  }

  /**
   * This tests the case in which the scale factor is valid, start time is invalid AND end time is
   * Invalid.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape5_a() {
    newAnimation.scaleShape(oval1, 3.79, 30, 130);
  }

  /**
   * This tests the case in which the scale factor is valid, but the start time is greater than the
   * end time.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape6_a() {
    newAnimation.scaleShape(rectangle1, 4.5, 55, 54);
  }

  /** Testing the case in which the start time is equal to the end time. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape7_a() {
    newAnimation.scaleShape(rectangle1, 4.5, 55, 55);
  }

  /** This tests the case in which the scale factor is valid and so are the start and end times. */
  @Test
  public void testLegalScaleShape1_a() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.scaleShape(rectangle1, 3.5, 20, 50);
    assertEquals(14.0, rectangle1.getLength(), 0.001);
    assertEquals(24.5, rectangle1.getWidth(), 0.001);

    newAnimation.scaleShape(square1, 2, 45, 50);
    assertEquals(8.0, square1.getLength(), 0.001);
    assertEquals(8.0, square1.getWidth(), 0.001);

    newAnimation.scaleShape(circle1, 1.0, 20, 50);
    assertEquals(4, circle1.getLength(), 0.001);
    assertEquals(4, circle1.getWidth(), 0.001);

    newAnimation.scaleShape(oval1, 0, 70, 71);
    assertEquals(0.0, oval1.getLength(), 0.001);
    assertEquals(0.0, oval1.getWidth(), 0.001);
  }

  // ======================== SCALE-SHAPE (W/O SCALE FACTOR) TESTS ===============================
  /** This tests the case in which the shape passed into the second scaleShape method is null. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape1_b() {
    newAnimation.scaleShape(null, 1, 3, 30, 40);
  }

  /** Testing the case in which the new length is equal to 0. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape2_b() {
    newAnimation.scaleShape(rectangle1, 0, 4, 30, 45);
  }

  /** Testing the case in which the new length is negative. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape3_b() {
    newAnimation.scaleShape(square1, -1, 3, 35, 40);
  }

  /** Testing the case in which the new width is 0. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape4_b() {
    newAnimation.scaleShape(circle1, 3.45, 0, 4, 5);
  }

  /** Testing the case where the new width is negative. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape5_b() {
    newAnimation.scaleShape(oval1, 4.58, -2.1, 60, 61);
  }

  /** Testing the case where the start time is invalid. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape6_b() {
    newAnimation.scaleShape(rectangle1, 5, 5, 5, 15);
  }

  /** Testing the case where the end time is invalid. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape7_b() {
    newAnimation.scaleShape(square1, 3, 4, 35, 71);
  }

  /** Testing the case where the start is equal to the end time. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape8_b() {
    newAnimation.scaleShape(circle1, 1.5, 3.4, 10, 10);
  }

  /** Testing the case where the end is less than the start. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalScaleShape9_b() {
    newAnimation.scaleShape(oval1, 2.3, 4.8, 10, 9);
  }

  /**
   * Testing the case in which the new length and new width are equal to the old length and old
   * width.
   */
  @Test
  public void testIllegalScaleShape10_b() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.scaleShape(rectangle1, 4, 7, 25, 35);
    assertEquals(4.0, rectangle1.getLength(), 0.001);
    assertEquals(7.0, rectangle1.getWidth(), 0.001);
  }

  /** Testing legal scale shapes. */
  @Test
  public void testLegalScaleShape1_b() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    // Scaling a rectangle to another rectangle
    newAnimation.scaleShape(rectangle1, 2, 1, 12, 23);
    assertEquals(2.0, rectangle1.getLength(), 0.001);
    assertEquals(1.0, rectangle1.getWidth(), 0.001);

    // Scaling a rectangle to a square
    newAnimation.scaleShape(rectangle1, 3, 3, 15, 20);
    assertEquals(3.0, rectangle1.getLength(), 0.001);
    assertEquals(3.0, rectangle1.getWidth(), 0.001);

    // Scaling a square to a rectangle
    newAnimation.scaleShape(square1, 1.0, 4.5, 40, 45);
    assertEquals(1.0, square1.getLength(), 0.001);
    assertEquals(4.5, square1.getWidth(), 0.001);

    // Scaling a square to another square
    newAnimation.scaleShape(square1, 6, 6, 40, 45);
    assertEquals(6.0, square1.getLength(), 0.001);
    assertEquals(6.0, square1.getWidth(), 0.001);

    // Scaling a circle to another circle
    newAnimation.scaleShape(circle1, 5, 5, 20, 25);
    assertEquals(5.0, circle1.getLength(), 0.001);
    assertEquals(5.0, circle1.getWidth(), 0.001);

    // Scaling a circle to an oval
    newAnimation.scaleShape(circle1, 4, 3, 20, 25);
    assertEquals(4.0, circle1.getLength(), 0.001);
    assertEquals(3.0, circle1.getWidth(), 0.001);

    // Scaling an oval to a circle
    newAnimation.scaleShape(oval1, 3, 3, 55, 60);
    assertEquals(3.0, oval1.getLength(), 0.001);
    assertEquals(3.0, oval1.getWidth(), 0.001);

    // Scaling an oval to another oval
    newAnimation.scaleShape(oval1, 2, 1, 60, 65);
    assertEquals(2.0, oval1.getLength(), 0.001);
    assertEquals(1.0, oval1.getWidth(), 0.001);
  }

  /** Testing the toString method. */
  @Test
  public void testToString() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    assertEquals(
        "Shapes:\n"
            + "Name: R1\n"
            + "Type: rectangle\n"
            + "Min corner: (0.0,0.0), Width: 7.0, Height: 4.0, Color: (200.0,100.0,60.0)\n"
            + "Appears at t=10.0\n"
            + "Disappears at t=100.0\n"
            + "\n"
            + "Name: S1\n"
            + "Type: rectangle\n"
            + "Min corner: (-3.0,-3.0), Width: 4.0, Height: 4.0, Color: (0.0,100.0,170.0)\n"
            + "Appears at t=30.0\n"
            + "Disappears at t=70.0\n"
            + "\n"
            + "Name: C1\n"
            + "Type: oval\n"
            + "Min corner: (5.0,5.0), Width: 4.0, Height: 4.0, Color: (40.0,150.0,60.0)\n"
            + "Appears at t=0.0\n"
            + "Disappears at t=100.0\n"
            + "\n"
            + "Name: O1\n"
            + "Type: oval\n"
            + "Min corner: (2.0,3.0), Width: 3.0, Height: 7.0, Color: (1.0,15.0,10.0)\n"
            + "Appears at t=50.0\n"
            + "Disappears at t=120.0\n\n",
        newAnimation.toString());
  }

  // ======================== SHAPE-JOURNEY TESTS ===============================
  /** This tests the case in which the name is null. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalShapeJourney1() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.scaleShape(rectangle1, 3.5, 20, 50);
    newAnimation.scaleShape(rectangle1, 3, 3, 15, 20);
    newAnimation.changeColor(rectangle1, 155, 155, 155, 30, 32);
    newAnimation.moveShape(rectangle1, 4, 8, 30, 60);
    newAnimation.showShapeJourney(null);
  }

  /** This tests the case in which the name doesn't exist. */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalShapeJourney2() {
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.showShapeJourney(rectangle1.getName());
  }

  /** This tests a legal shapeJourney. */
  @Test
  public void testLegalShapeJourney1() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.scaleShape(rectangle1, 3.5, 20, 50);
    newAnimation.scaleShape(rectangle1, 3, 3, 15, 20);
    newAnimation.changeColor(rectangle1, 155, 155, 155, 30, 32);
    newAnimation.moveShape(rectangle1, 4, 8, 30, 60);
    assertEquals(
        "\nName: R1\nType: rectangle\n"
            + "Min corner: (4.0,8.0), Width: 3.0, Height: 3.0, Color: (155.0,155.0,155.0)\n"
            + "Appears at t=10.0\n"
            + "Disappears at t=100.0\n"
            + "Shape R1 scales from Width: 4.0, Height: 7.0 to Width: 14.0, Height: 24.5 "
            + "from t=20 to t=50\n"
            + "Shape R1 scales from Width: 14.0, Height: 24.5 to Width: 3.0, Height: 3.0 "
            + "from t=15 to t=20\n"
            + "Shape R1 changes color from (200.0,100.0,60.0) to (155.0,155.0,155.0) "
            + "from t=30 to t=32\n"
            + "Shape R1 moves from (0.0,0.0) to (4.0,8.0) from time t=30 to t=60\n",
        newAnimation.showShapeJourney(rectangle1.getName()));
  }
}
