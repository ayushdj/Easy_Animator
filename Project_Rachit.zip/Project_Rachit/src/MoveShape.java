public class MoveShape implements SimpleAnimationModel {


  @Override
  public SimpleAnimationModel visit(IShape shape, double timeStamp) {
    return null;
  }
}
