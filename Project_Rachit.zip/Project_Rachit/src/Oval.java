import java.awt.*;

public class Oval extends AbstractShape {

  public Oval(
          double x,
          double y,
          double length,
          double width,
          Color color,
          int timeAppear,
          int timeDisappear) {
    super(x, y, length, width, color, timeAppear, timeDisappear);
  }

  @Override
  public double getArea() {
    return Math.PI * this.length * this.width;
  }

  @Override
  public double getPerimeter() {
    double stuffInSquareRoot = (Math.pow(this.length, 2) + Math.pow(this.length, 2)) / 2;
    double perimeter = 2 * Math.PI * Math.sqrt(stuffInSquareRoot);
    return perimeter;
  }

  @Override
  public void accept(SimpleAnimationModel object, double timeStamp) {
    object.visit(this, timeStamp);
  }
}
