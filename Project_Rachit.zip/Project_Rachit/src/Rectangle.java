import java.awt.*;

public class Rectangle extends AbstractShape {


  public Rectangle(
          double x,
          double y,
          double length,
          double width,
          Color color,
          int timeAppear,
          int timeDisappear) {
    super(x, y, length, width, color, timeAppear, timeDisappear);
  }

  @Override
  public double getArea() {
    return this.length * this.width;
  }

  @Override
  public double getPerimeter() {
    return 2 * this.length + 2 * this.width;
  }

  @Override
  public void accept(SimpleAnimationModel object, double timeStamp) {

  }

}
