public interface SimpleAnimationModel {

  SimpleAnimationModel visit(IShape shape, double timeStamp);
}
