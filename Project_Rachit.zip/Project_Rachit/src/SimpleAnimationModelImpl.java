import java.util.HashMap;

public class SimpleAnimationModelImpl implements SimpleAnimationModel {

  private HashMap shapes;

  public SimpleAnimationModelImpl(IShape shape) {
    this.shapes = new HashMap();
  }


  @Override
  public SimpleAnimationModel visit(IShape shape, double timeStamp) {
    return null;
  }
}
