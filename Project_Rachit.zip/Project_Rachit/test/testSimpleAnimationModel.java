import org.junit.Before;
import org.junit.Test;

public class testSimpleAnimationModel {

  @Before
  public void setUp(){

    // make a simpleAnimation model instance
    // make a shape instance ( ex: rectangle)
    // rectangle.accept( new MoveShape(int newX, int newY))

  }
}
