package cs5004.animator.model;

public enum ShapeType {
  OVAL,
  RECTANGLE;
}
