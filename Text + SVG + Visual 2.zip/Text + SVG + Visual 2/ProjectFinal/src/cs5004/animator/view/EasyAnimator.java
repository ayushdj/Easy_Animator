package cs5004.animator.view;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import cs5004.animator.util.AnimationBuilder;
import cs5004.animator.util.AnimationReader;
import cs5004.animator.model.EasyAnimatorModel;
import cs5004.animator.model.EasyAnimatorModelImpl;
import cs5004.animator.model.IShape;
import javax.swing.*;

public final class EasyAnimator {

  public static void main(String[] args) throws IOException {

    // our model
    EasyAnimatorModel myModel = new EasyAnimatorModelImpl();

    //base path to the text files
    String basePath = "/Users/rachitmehta/Desktop/5004/Homeworks/Project/Text + SVG + Visual 2/ProjectFinal/src/cs5004/animator/util/";

    //variables for our command line arguments
    String inputFile = "buildings.txt";
    String outputFile = "";
    double speed = 0;
    double defaultSpeed = 1.0;
    String viewType = "";
    viewType = "visual";
    boolean flag = false;


    try {
      for (int i = 0; i < args.length; i += 2) {
        if (args[i].equalsIgnoreCase("-in")) {
          inputFile = args[i + 1];
        } else if (args[i].equalsIgnoreCase("-out")) {
          outputFile = args[i + 1];
        } else if (args[i].equalsIgnoreCase("-view")) {
          viewType = args[i + 1];
        } else if (args[i].equalsIgnoreCase("-speed")) {
          speed = Integer.parseInt(args[i + 1]);
        } else {
          throw new IllegalArgumentException("one of your arguments is not valid");
        }
      }

    } catch (IndexOutOfBoundsException e) {
      //throw new IllegalArgumentException("arguments are not in pairs (i.e. one of your arguments"
      //   + " is missing");
      JOptionPane.showMessageDialog(null, "Command-Line argument error: Too many arguments " +
              "or too little arguments", "Argument Error", JOptionPane.ERROR_MESSAGE);

    } catch (NumberFormatException e2) {
      //throw new IllegalArgumentException("Speed is not an integer");
      JOptionPane.showMessageDialog(null, "Speed is not an integer", "Data type error", JOptionPane.ERROR_MESSAGE);

    } catch (Exception e) {
      //throw new IllegalArgumentException("bruh are you gae");
      JOptionPane.showMessageDialog(null, "Something isn't right-Check your commandline arguments", "Unknown Error", JOptionPane.ERROR_MESSAGE);
    }


    if (inputFile.equalsIgnoreCase("")) {
      //throw new IllegalArgumentException("Must specify an input file");
      JOptionPane.showMessageDialog(null, "InputFile is missing", "Input File Error", JOptionPane.ERROR_MESSAGE);
    }

    if (viewType.equalsIgnoreCase("")) {
      //throw new IllegalArgumentException("You have to specify a way to view your animation");
      JOptionPane.showMessageDialog(null, "There is no view", "View Error", JOptionPane.ERROR_MESSAGE);
    }

    if (viewType.equalsIgnoreCase("svg") && outputFile.equalsIgnoreCase("")) {
      flag = true;
    }

    //out = "output.svg";
    //speed = 30;

    //Builder
    AnimationBuilder<EasyAnimatorModel> builder = new EasyAnimatorModelImpl.BobTheBuilder(myModel);
    //Readable
    Readable readable = new FileReader(basePath + "hanoi.txt");
    //Parse File
    AnimationReader.parseFile(readable, builder);

    // gets the correct instance of the view from the view factory
    IView ourView = ViewFactory.getView(viewType);

    // checks if the viewType is text
    if(ourView.getType().equals("text")){
      TextView.showView(myModel);

      //checks if the viewType is svg
    } else if (ourView.getType().equals("svg")){
      if (!flag) {
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
        writer.write(SvgView.showView(myModel, speed));
        writer.close();
      } else {
        System.out.println(SvgView.showView(myModel, speed));
      }

      //otherwise the view type is going to be visual
    } else {
      SwingFrame newAnimation = new SwingFrame(myModel.getX(), myModel.getY(),
              myModel.getCanvasWidth(), myModel.getCanvasHeight(), myModel.getShapes());
      double tick = 0;
      //newAnimation.currentView(myModel.getShapesAtTimeStamp(tick));
      while (tick <= myModel.getEndTime()) {
        List<IShape> mutatedShapes = myModel.getShapesAtTimeStamp(tick);
        newAnimation.currentView(mutatedShapes);
        // tick corresponds to frames per second
        tick++;
        try {
          // speed
          Thread.sleep(100);
        } catch (InterruptedException ex) {
          Thread.currentThread().interrupt();
        }
      }
    }


    /*
    switch (viewType) {
      case "text": {
        TextView.showView(myModel);
        break;
      }
      case "svg": {
        if (!flag) {
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
          writer.write(SvgView.showView(myModel, speed));
          writer.close();
        } else {
          System.out.println(SvgView.showView(myModel, speed));
        }
        break;
      }
      case "visual": {
        SwingFrame newAnimation = new SwingFrame(myModel.getX(), myModel.getY(), myModel.getCanvasWidth(), myModel.getCanvasHeight(), myModel.getShapes());
        double tick = 0;
        //newAnimation.currentView(myModel.getShapesAtTimeStamp(tick));
        while (tick <= myModel.getEndTime()) {
          List<IShape> mutatedShapes = myModel.getShapesAtTimeStamp(tick);
          newAnimation.currentView(mutatedShapes);
          // tick corresponds to frames per second
          tick++;
          try {
            // speed
            Thread.sleep(100);
          } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
          }
        }
        break;
      }
      default: {
        break;
      }
    }

     */

  }
}
