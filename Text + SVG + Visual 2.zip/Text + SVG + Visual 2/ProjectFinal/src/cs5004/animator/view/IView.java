package cs5004.animator.view;

public interface IView {

  String getType();
}
