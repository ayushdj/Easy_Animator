package cs5004.animator.view;

import java.awt.*;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.util.List;
import javax.swing.*;
import cs5004.animator.model.IShape;

public class SwingFrame extends JFrame {

  private SwingPanel panel;

  public SwingFrame(int x, int y, int width, int height, List<IShape> listOfMutatedShapes){

    super("Our grand animation");

    BorderLayout newBorder = new BorderLayout();
    this.setLayout(newBorder);
    this.panel = new SwingPanel(listOfMutatedShapes);
    this.add(this.panel, BorderLayout.CENTER);
    this.panel.setVisible(true);

    JScrollBar verticalScrollBar = new JScrollBar(JScrollBar.VERTICAL, 0, 100, -200, 200);
    class VerticalAdjustmentListener implements AdjustmentListener{

      @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {
        setPanelOffSetY(e.getValue());

      }
    }
    JScrollBar horizontalScrollBar = new JScrollBar(JScrollBar.HORIZONTAL, 0, 100, -200, 200);
    class HorizontalAdjustmentListener implements AdjustmentListener{

      @Override
      public void adjustmentValueChanged(AdjustmentEvent e) {

        setPanelOffSetX(e.getValue());

      }
    }
    verticalScrollBar.addAdjustmentListener(new VerticalAdjustmentListener());
    horizontalScrollBar.addAdjustmentListener(new HorizontalAdjustmentListener());
    this.getContentPane().add(verticalScrollBar, BorderLayout.EAST);
    this.getContentPane().add(horizontalScrollBar, BorderLayout.SOUTH);

    setSize(width, height);
    setLocation(x, y);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);
  }

  public SwingPanel getPanel(){
        return this.panel;
  }

  public void currentView(List<IShape> listOfMutatedShapes) {
    this.revalidate();
    this.panel.setModel((listOfMutatedShapes));
    this.repaint();
  }

  private void setPanelOffSetY(int value){
    this.panel.setPanelOffSetY(value);
  }

  private void setPanelOffSetX(int value){
    this.panel.setPanelOffSetX(value);
  }

}
