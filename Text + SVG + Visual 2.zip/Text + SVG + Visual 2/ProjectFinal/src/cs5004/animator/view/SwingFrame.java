package cs5004.animator.view;

import java.awt.*;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.util.List;
import javax.swing.*;
import cs5004.animator.model.IShape;

public class SwingFrame extends JFrame {

  private SwingPanel panel;

  public SwingFrame(int x, int y, int width, int height, List<IShape> listOfMutatedShapes){

    super("Our grand animation");

    this.panel = new SwingPanel(listOfMutatedShapes);
    this.add(this.panel, BorderLayout.CENTER);
    this.panel.setVisible(true);

    JScrollBar verticalScrollBar = new JScrollBar(JScrollBar.VERTICAL);
    JScrollBar horizontalScrollBar = new JScrollBar(JScrollBar.HORIZONTAL);
    verticalScrollBar.addAdjustmentListener(new MyAdjustmentListener(this));
    horizontalScrollBar.addAdjustmentListener(new MyAdjustmentListener(this));
    this.getContentPane().add(verticalScrollBar, BorderLayout.EAST);
    this.getContentPane().add(horizontalScrollBar, BorderLayout.SOUTH);

    /*
    JScrollPane scrollable = new JScrollPane(this.panel);
    scrollable.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    scrollable.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    this.getContentPane().add(scrollable);

     */

    setSize(width, height);
    setLocation(x, y);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);
    }

  public void currentView(List<IShape> listOfMutatedShapes) {
    //this.revalidate();
    this.panel.setModel((listOfMutatedShapes));
    this.repaint();
  }

}
