package cs5004.animator.view;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.List;
import javax.swing.*;
import javax.swing.border.LineBorder;
import cs5004.animator.model.IShape;
import cs5004.animator.model.ShapeType;

public class SwingPanel extends JPanel {

  private List<IShape> realModel;


  public SwingPanel(List<IShape> realModel) {
    super(true);
    this.realModel = realModel;
    setBackground(Color.WHITE);
    setBorder(new LineBorder(Color.black, 3));

  }

  public void setModel( List<IShape> model) {
    this.realModel = model;
  }

  @Override
  public void paintComponent(Graphics g) {

    super.paintComponent(g);

    Graphics2D g2 = (Graphics2D) g;
    if ( this.realModel == null) {
      return;
    }
    for (IShape shape: this.realModel) {
      if (shape.getShapeType() == ShapeType.RECTANGLE) {
        g2.setColor(shape.getColor());
        g2.draw(new Rectangle2D.Double(shape.getX(), shape.getY(),shape.getWidth(), shape.getLength()));
        g2.fill(new Rectangle2D.Double(shape.getX(), shape.getY(),shape.getWidth(), shape.getLength()));
      }

      if (shape.getShapeType() == ShapeType.OVAL) {
        g2.setColor(shape.getColor());
        g2.draw(new Ellipse2D.Double(shape.getX(), shape.getY(),shape.getWidth(), shape.getLength()));
        g2.fill(new Ellipse2D.Double(shape.getX(), shape.getY(),shape.getWidth(), shape.getLength()));
      }
    }
  }
}
