package cs5004.animator.view;

public class ViewFactory {

  public static IView getView(String viewType){
    if(viewType.equals("svg")){
      return new SvgView();
    } else if(viewType.equals("text")) {
      return new TextView();
    } else {
      return new VisualView();
    }

  }
}
