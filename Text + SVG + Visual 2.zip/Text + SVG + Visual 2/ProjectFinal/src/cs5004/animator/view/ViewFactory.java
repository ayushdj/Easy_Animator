package cs5004.animator.view;

import cs5004.animator.model.EasyAnimatorModel;

public class ViewFactory<T> {

  public static IView getView(EasyAnimatorModel model, String viewType){
    if(viewType.equals("svg")){
      return new SvgView(model);
    } else if(viewType.equals("text")) {
      return new TextView(model);
    } else if(viewType.equals("visual")) {
      return new VisualView(model);
    }
    return null;
  }
}
