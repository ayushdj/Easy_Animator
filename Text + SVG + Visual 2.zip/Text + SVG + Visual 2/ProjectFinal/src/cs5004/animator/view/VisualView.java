package cs5004.animator.view;

public class VisualView implements IView{

  @Override
  public String getType() {
    return "visual";
  }
}
