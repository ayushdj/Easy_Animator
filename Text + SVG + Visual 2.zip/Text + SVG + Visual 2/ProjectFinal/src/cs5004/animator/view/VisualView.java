package cs5004.animator.view;

import cs5004.animator.model.EasyAnimatorModel;

public class VisualView implements IView{

  SwingFrame frame;
  EasyAnimatorModel model;



  public VisualView(EasyAnimatorModel model) {

    if(model == null) {
      throw new IllegalArgumentException("The model you passed in is null");
    }
    this.model = model;

    frame = new SwingFrame(model.getX(), model.getY(),
            model.getCanvasWidth(), model.getCanvasHeight(), model.getShapes());

  }
  @Override
  public String getType() {
    return "visual";
  }

  @Override
  public String showView() {
    return null;
  }

  public SwingFrame getFrame() {
    return this.frame;
  }

  public EasyAnimatorModel getModel() {
    return this.model;
  }
}
