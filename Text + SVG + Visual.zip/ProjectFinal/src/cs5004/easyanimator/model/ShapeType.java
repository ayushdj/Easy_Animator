package cs5004.easyanimator.model;

public enum ShapeType {
  OVAL,
  RECTANGLE;
}
