package cs5004.animator.view;

import java.util.List;
import javax.swing.*;
import cs5004.animator.model.IShape;

public class SwingFrame extends JFrame {

  private SwingPanel panel;

  public SwingFrame(int x, int y, int width, int height, List<IShape> model){

    super("Our grand animation");
    setSize(width, height);
    setLocation(x, y);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.panel = new SwingPanel(model);
    this.setVisible(true);
    this.add(this.panel);
    this.panel.setVisible(true);
  }

  public void currentView(List<IShape> model) {
    //this.revalidate();
    this.panel.setModel((model));
    this.repaint();

  }
}