package cs5004.animator.view;

import cs5004.animator.model.EasyAnimatorModel;

/**
 * This class represents a text based view of the animation.
 */
public class TextView {

  /**
   * dmklwadkmnlaldmnwad
   * @param model
   */
  public static void showView(EasyAnimatorModel model) {
    System.out.println(model.toString());
  }
}
