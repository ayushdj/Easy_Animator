package cs5004.animator.view;

import java.awt.*;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.*;

class MyAdjustmentListener implements AdjustmentListener {

  SwingFrame frame;

  public MyAdjustmentListener(SwingFrame frame) {
    this.frame = frame;

  }

  @Override
  public void adjustmentValueChanged(AdjustmentEvent e) {
    frame.revalidate();
    frame.repaint();
  }
}
