package cs5004.animator.view;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.swing.*;

import cs5004.animator.model.EasyAnimatorModel;
import cs5004.animator.model.IShape;

public class ViewFactory<T> {

  public static void getView(EasyAnimatorModel model, String viewType, String outputFile, double speed) throws IOException {
    try {
      if (viewType.equals("svg")) {
        if (outputFile == null || outputFile.isEmpty()) {
          System.out.println(new SvgView(model).showView());
        } else {
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
          writer.write(new SvgView(model).showView());
          writer.close();
        }
      } else if (viewType.equals("text")) {
        //return new TextView(model);
        new TextView((model)).showView();
      } else if (viewType.equals("visual")) {
        double tick = 0;
        IView obj = new VisualView(model);
        while (tick <= model.getEndTime()) {
          List<IShape> mutatedShapes = model.getShapesAtTimeStamp(tick);
          obj.getFrame().currentView(mutatedShapes);
          // tick corresponds to frames per second
          tick++;
          try {
            // speed
            Thread.sleep((long)((long) 100/speed));
            //Thread.sleep(100);
          } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
          }
        }
      }
    } catch (NullPointerException e) {
      JOptionPane.showMessageDialog(null, "Invalid View Type", "View Error", JOptionPane.ERROR_MESSAGE);

    } catch (IllegalArgumentException e) {
      JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
    } catch(Exception e) {
      JOptionPane.showMessageDialog(null, e.getMessage(), "View Error", JOptionPane.ERROR_MESSAGE);
    }
  }
}
