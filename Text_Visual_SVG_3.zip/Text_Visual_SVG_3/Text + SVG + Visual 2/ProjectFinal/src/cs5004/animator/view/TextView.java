package cs5004.animator.view;

import cs5004.animator.model.EasyAnimatorModel;

/**
 * This class represents a text based view of the animation.
 */
public class TextView implements IView {

  EasyAnimatorModel model;

  public TextView(EasyAnimatorModel model) {

    if(model == null) {
      throw new IllegalArgumentException("The model you passed in is null");
    }

    this.model = model;
  }

  /**
   * dmklwadkmnlaldmnwad
   */
  public String showView() {

    return this.model.toString();
  }

  @Override
  public SwingFrame getFrame() {
    return null;
  }

  @Override
  public String getType(){
    return "text";
  }

  public EasyAnimatorModel getModel() {
    return model;
  }
}
