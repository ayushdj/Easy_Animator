import java.awt.*;

public abstract class AbstractShape implements IShape {

  protected double x;
  protected double y;
  protected double length;
  protected double width;
  protected Color color;
  protected int timeAppear;
  protected int timeDisappear;

  public AbstractShape(
      double x,
      double y,
      double length,
      double width,
      Color color,
      int timeAppear,
      int timeDisappear) {

    this.x = x;
    this.y = y;
    this.length = length;
    this.width = width;
    this.color = color;
    this.timeAppear = timeAppear;
    this.timeDisappear = timeDisappear;
  }

  @Override
  public abstract double getArea();

  @Override
  public abstract double getPerimeter();

  @Override
  public double getX() {
    return this.x;
  }

  @Override
  public double getY() {
    return this.y;
  }

  @Override
  public double getLength() {
    return this.length;
  }

  @Override
  public double getWidth() {
    return this.width;
  }

  @Override
  public void setNewXY(double x, double y) {
    this.x = x;
    this.y = y;
  }

  /**
  @Override
  public abstract SimpleAnimationModel playAnimation(SimpleAnimationModel object);
  */
}
