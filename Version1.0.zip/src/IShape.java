public interface IShape {


  double getArea();
  double getPerimeter();
  double getX();
  double getY();
  double getLength();
  double getWidth();

  void setNewXY(double x, double y);

  //SimpleAnimationModel playAnimation(SimpleAnimationModel object);

}
