public interface SimpleAnimationModel {


  //SimpleAnimationModel playAnimation(SimpleAnimationModel object);


  void moveShape(double newX, double newY);

  void changeColor(IShape shape, double timeFrom, double timeTo);

  void changeShape(IShape shape, double timeFrom, double timeTo);

  void scaleShape(double scaleFactor);


}
