public class SimpleAnimationModelImpl implements SimpleAnimationModel {

  private IShape shape;

  public SimpleAnimationModelImpl(IShape shape) {
    this.shape = shape;
  }

  /**
  @Override
  public SimpleAnimationModel playAnimation(SimpleAnimationModel object) {
    return this.shape.playAnimation(object);
  }
  */

  @Override
  public void moveShape(double newX, double newY) {

  }

  @Override
  public void changeColor(IShape shape, double timeFrom, double timeTo) {

  }

  @Override
  public void changeShape(IShape shape, double timeFrom, double timeTo) {

  }

  @Override
  public void scaleShape(double scaleFactor) {

  }
}

