public class SimpleAnimationModelTest {
}
