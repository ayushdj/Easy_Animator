import java.util.List;

public class ChangeColor implements EasyAnimator{
  @Override
  public void play(IShape shape, double time) {

  }

  @Override
  public String stringForm(String key) {
    return null;
  }
}
