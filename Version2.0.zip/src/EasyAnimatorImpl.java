import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EasyAnimatorImpl {

  // This is a list of original states our all of our shapes in the animation
  private List<IShape> shapes;

  // Key(String) and value = list of all the mutations that take place on that particular object
  // clones of the original object during a particular time interval.
  private HashMap<String, List<EasyAnimator>> animations;

  public EasyAnimatorImpl() {
    this.shapes = new ArrayList();
    this.animations = new HashMap();
  }

  // Hashmap.put(key: shape.getName, value: list.add(newMoveShape(fields)))

  public void addShape(IShape shape) {

    if (shape == null) {
      throw new NullPointerException("You can't pass a null object");
    }

    if ( animations.containsKey(shape.getName())) {
      throw new IllegalArgumentException("This key already exists");
    }

    this.shapes.add(shape);
    IShape clonedShape = shape.cloneShape();
    this.animations.put(clonedShape.getName(), new ArrayList());
  }

  public void move(IShape shape, int newX, int newY, double start, double end) {

    MoveShape moveShape = new MoveShape(new Point2D.Double(newX, newY), new Point2D.Double(shape.getX(), shape.getY()), start, end);
    //shape.
    this.animations.get(shape.getName()).add(moveShape);
    //moveShape.play(shape, )


  }

  public String toString() {
    String str = "Shapes:";
    for (IShape each: this.shapes) {
      str += each.toString();
    }

    str += "\n";

    for (String each : this.animations.keySet()) {
      for (EasyAnimator obj : this.animations.get(each)) {
        str += obj.stringForm(each);
      }
    }
    return str;
  }
  public HashMap<String, List<EasyAnimator>> getAnimations() {
    return this.animations;
  }


}
