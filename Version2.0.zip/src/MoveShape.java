import java.awt.geom.Point2D;
import java.util.List;

public class MoveShape implements EasyAnimator {

  Point2D newPos;
  Point2D oldPos;
  double start;
  double end;

  public MoveShape(Point2D newPos, Point2D oldPos, double start, double end) {

    this.newPos = newPos;
    this.oldPos = oldPos;
    this.start = start;
    this.end = end;
  }

  @Override
  public void play(IShape shape, double time) {
    shape.setNewXY(this.newPos.getX(), this.newPos.getY());
  }

  @Override
  public String stringForm(String key) {
    String str;
    str =
        "Shape "
            + key
            + " moves from "
            + "("
            + this.oldPos.getX() + "," + this.oldPos.getY()
            + ")"
            + " to "
            + "("
            + this.newPos.getX() + "," + this.newPos.getY()
            + ")"
            + " from time t="
            + String.format("%.0f", start)
            + " to t="
            + String.format("%.0f", end);
    return str;
  }
}
