import java.awt.*;

public class Oval extends AbstractShape {

  public Oval(String name,
          double x,
          double y,
          double length,
          double width,
          Color color,
          int timeAppear,
          int timeDisappear) {
    super(name, x, y, length, width, color, timeAppear, timeDisappear);
  }

  @Override
  public double getArea() {
    //return Math.PI * this.length * this.width;
    return 1.0;
  }

  @Override
  public double getPerimeter() {
    //double stuffInSquareRoot = (Math.pow(this.length, 2) + Math.pow(this.length, 2)) / 2;
    //double perimeter = 2 * Math.PI * Math.sqrt(stuffInSquareRoot);
    //return perimeter;
    return 1.0;
  }

  @Override
  public void accept(EasyAnimator object, double timeStamp) {
    //object.visit(this, timeStamp);
  }

  @Override
  public IShape cloneShape() {
    return new Oval(this.name, this.x, this.y, this.length, this.width, this.color, this.timeAppear, this.timeDisappear);
  }

  @Override
  public String toString() {
    String shapeDescription;
    shapeDescription =
            "\nName: "
                    + this.name
                    + "\nType: "
                    + "oval"
                    + "\nMin corner: "
                    + "("
                    + this.x
                    + ","
                    + this.y
                    + ")"
                    + ", "
                    + "Width: "
                    + this.width
                    + ", "
                    + "Height: "
                    + this.length
                    + ", "
                    + "Color: "
                    + "("
                    + (float) this.color.getRed()
                    + ","
                    + (float) this.color.getGreen()
                    + ","
                    + (float) this.color.getBlue()
                    + ")"
                    + "\nAppears at t="
                    + this.timeAppear
                    + "\nDisappears at t="
                    + this.timeDisappear
                    + "\n";

    return shapeDescription;
  }
}
