import java.util.List;

public class ScaleShape implements EasyAnimator{
  double oldWidth;
  double oldLength;


  @Override
  public void play(IShape shape, double time) {

  }

  @Override
  public String stringForm(String key) {
    String str;
    str = "Shape "
            + key
            + " scales from Width: ";
    return str;
  }
}
