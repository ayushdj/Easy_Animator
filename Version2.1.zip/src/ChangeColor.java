import java.awt.Color;

public class ChangeColor implements EasyAnimator {

  Color newColor;
  Color oldColor;
  double start;
  double end;

  public ChangeColor(Color newColor, IShape shape, double start, double end) {
    this.newColor = newColor;
    this.oldColor = shape.getColor();
    this.start = start;
    this.end = end;
  }

  @Override
  public void play(IShape shape, double time) {

  }

  @Override
  public String stringForm(String key) {
    String str;
    str =
            "Shape "
                    + key
                    + " changes color from ("
                    + (float) oldColor.getRed()
                    + ","
                    + (float) oldColor.getGreen()
                    + ","
                    + (float) oldColor.getBlue()
                    + ") to ("
                    + (float) newColor.getRed()
                    + ","
                    + (float) newColor.getGreen()
                    + ","
                    + (float) newColor.getBlue()
                    + ") from t="
                    + String.format("%.0f", start)
                    + " to t="
                    + String.format("%.0f\n", end);
    return str;
  }

  @Override
  public double getStart(){
    return start;
  }
}
