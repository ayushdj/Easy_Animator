import java.util.List;

public interface EasyAnimator {

  void play(IShape shape, double time);
  String stringForm(String key);
  double getStart();
}
