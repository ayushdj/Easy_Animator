import java.awt.*;
import java.awt.geom.Point2D;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class EasyAnimatorImpl {

  // This is a list of original states our all of our shapes in the animation
  private List<IShape> shapes;

  // Key(String) and value = list of all the mutations that take place on that particular object
  // clones of the original object during a particular time interval.
  private HashMap<String, List<EasyAnimator>> animations;

  public EasyAnimatorImpl() {
    this.shapes = new ArrayList();
    this.animations = new HashMap();
  }

  // Hashmap.put(key: shape.getName, value: list.add(newMoveShape(fields)))

  public void addShape(IShape shape) throws NullPointerException,
          IllegalArgumentException{

    if (shape == null) {
      throw new NullPointerException("You can't pass a null shape");
    }

    if (animations.containsKey(shape.getName())) {
      throw new IllegalArgumentException("This key already exists");
    }

    this.shapes.add(shape);
    IShape clonedShape = shape.cloneShape();
    this.animations.put(clonedShape.getName(), new ArrayList());
  }

  public void moveShape(IShape shape, int newX, int newY, double start,
                        double end) throws IllegalArgumentException {
    if(shape == null) {
      throw new NullPointerException("You can't pass a null shape");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException("Start time before shape appears or "
              + "end time after shape disappears.");
    }
    EasyAnimator moveShape = new MoveShape(new Point2D.Double(newX, newY),
            shape, start, end);
    //moveShape.play(shape, )
    this.animations.get(shape.getName()).add(moveShape);
  }

  public void changeColor(IShape shape, int r, int g, int b, double start,
                          double end) throws IllegalArgumentException {

    if(shape == null) {
      throw new NullPointerException("You can't pass a null shape");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException("Start time before shape appears or "
              + "end time after shape disappears.");
    }
    EasyAnimator changeColor = new ChangeColor(new Color(r, g, b), shape,
            start, end);
    //changeColor.play(shape, )
    this.animations.get(shape.getName()).add(changeColor);
  }

  public void scaleShape(IShape shape, double newLength, double newWidth,
                         double start, double end) {
    if(shape == null) {
      throw new NullPointerException("You can't pass a null shape");
    }

    if (newLength < 0 || newWidth < 0) {
      throw new IllegalArgumentException("New length or width is negative.");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException("Start time before shape appears or "
              + "end time after shape disappears.");
    }
    EasyAnimator scaleShape = new ScaleShape(newLength, newWidth, shape,
            start, end);
    //scaleShape.play(shape, )
    this.animations.get(shape.getName()).add(scaleShape);
  }

  public String toString() {
    String str = "Shapes:";
    for (IShape each : this.shapes) {
      str += each.toString();
    }

    str += "\n";

    List<ArrayList<String>> list= new ArrayList<>();
    int count = 0;

    for (String each : this.animations.keySet()) {
      for (EasyAnimator obj : this.animations.get(each)) {
        list.add(new ArrayList<>());
        list.get(count).add(Double.toString(obj.getStart()));
        list.get(count).add(obj.stringForm(each));
        count++;
      }
    }

    list.sort((o1, o2) -> {
      if (Double.parseDouble(o1.get(0)) < Double.parseDouble(o2.get(0))) return -1;
      if (Double.parseDouble(o1.get(0)) > Double.parseDouble(o2.get(0))) return 1;
      return 0;
    });

    for (ArrayList<String> subList : list) {
      str += subList.get(1);
    }
    return str;
  }

  /**
   * Getter method for hashMap.
   * @return Hashmap.
   */
  public HashMap<String, List<EasyAnimator>> getAnimations() {
    return this.animations;
  }


}
