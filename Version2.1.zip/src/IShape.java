import java.awt.*;

public interface IShape {

    double getArea();
    double getPerimeter();
    double getX();
    double getY();
    double getLength();
    double getWidth();
    Color getColor();
    void setNewXY(double x, double y);
    double getTimeAppear();
    double getTimeDisappear();
    String getName();

    void accept(EasyAnimator object, double timeStamp);
    IShape cloneShape();
}
