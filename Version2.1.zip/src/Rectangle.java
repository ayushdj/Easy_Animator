import java.awt.*;

public class Rectangle extends AbstractShape {

  public Rectangle(
      String name,
      double x,
      double y,
      double length,
      double width,
      Color color,
      double timeAppear,
      double timeDisappear) {
    super(name, x, y, length, width, color, timeAppear, timeDisappear);
  }

  @Override
  public double getArea() {
    return this.length * this.width;
  }

  @Override
  public double getPerimeter() {
    return 2 * this.length + 2 * this.width;
  }

  @Override
  public void accept(EasyAnimator object, double timeStamp) {

    // MoveShapeobject.play(this, timeStamp);

  }



  @Override
  public IShape cloneShape() {
    return new Rectangle(
        this.name,
        this.x,
        this.y,
        this.length,
        this.width,
        this.color,
        this.timeAppear,
        this.timeDisappear);
  }

  @Override
  public String toString() {
    String shapeDescription;
    shapeDescription =
        "\nName: "
            + this.name
            + "\nType: "
            + "rectangle"
            + "\nMin corner: "
            + "("
            + this.x
            + ","
            + this.y
            + ")"
            + ", "
            + "Width: "
            + this.width
            + ", "
            + "Height: "
            + this.length
            + ", "
            + "Color: "
            + "("
            + (float) this.color.getRed()
            + ","
            + (float) this.color.getGreen()
            + ","
            + (float) this.color.getBlue()
            + ")"
            + "\nAppears at t="
            + this.timeAppear
            + "\nDisappears at t="
            + this.timeDisappear
            + "\n";

    return shapeDescription;
  }
}
