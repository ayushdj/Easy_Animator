import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This class is the Model of our animation. The model is responsible for implementing the logic
 * that updates the state of objects to eventually pass that information to the controller. Our
 * EasyAnimatorModel model implements the logic to change the state of IShape objects to represent
 * animations on them.
 */
public class EasyAnimatorModel {

  // This is a list of original states our all of our shapes in the animation
  private List<IShape> shapes;

  // Key(String) and value = list of all the mutations that take place on that particular object
  // clones of the original object during a particular time interval.
  private HashMap<String, List<AnimationChanges>> animations;

  /**
   * This constructor initializes our EasyAnimatorModel object. It initializes a List that stores
   * the original objects and their original states. It also initializes a HashMap that stores the
   * String names of the objects as the key, and the value is a List of objects such as MoveShape,
   * ScaleShape, ChangeColor that change the state of our IShape object.
   */
  public EasyAnimatorModel() {
    this.shapes = new ArrayList();
    this.animations = new HashMap();
  }

  // Hashmap.put(key: shape.getName, value: list.add(newMoveShape(fields)))

  /**
   * This method adds an IShape object to the animation. Once the object is added it's added both
   * to the List of objects as well as the HashMap.
   * @param shape The IShape object that gets added to our data structure.
   * @throws NullPointerException We throw exception if null is passed in instead of IShape object.
   * @throws IllegalArgumentException We throw this if an IShape object is passed in with a name
   *                                  that already exists in our animation.
   */
  public void addShape(IShape shape) throws NullPointerException,
          IllegalArgumentException{

    if (shape == null) {
      throw new NullPointerException("You can't pass a null shape");
    }

    if (animations.containsKey(shape.getName())) {
      throw new IllegalArgumentException("This key already exists");
    }

    this.shapes.add(shape);
    IShape clonedShape = shape.cloneShape();
    this.animations.put(clonedShape.getName(), new ArrayList());
  }

  /**
   * This method is called upon by the EasyAnimatorModel object to move an IShape object from its
   * current (x,y) position to the new (x,y) position passed in the argument for the duration of the
   * start and end time also passed in the argument. This method delegates the changes to each
   * MoveShape object that will mutate the position of IShape object.
   * @param shape The IShape object that we want to move.
   * @param newX The new x-coordinate of the IShape object.
   * @param newY The new y-coordinate of the IShape object.
   * @param start The start time at which we want the movement to start.
   * @param end The end time at which we want the movement to end.
   * @throws IllegalArgumentException We throw this exception, when null is passed in instead of
   *                                  IShape object, when the start in the argument < IShape
   *                                  object's timeAppear, when the end time > IShape object's
   *                                  timeDisappear, when start > end.
   */
  public void moveShape(IShape shape, int newX, int newY, double start,
                        double end) throws IllegalArgumentException {
    if(shape == null) {
      throw new IllegalArgumentException("You can't pass a null shape");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException("Start time before shape appears or "
              + "end time after shape disappears.");
    }

    if (start > end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }
    AnimationChanges moveShape = new MoveShape(new Point2D.Double(newX, newY),
            shape, start, end);
    //moveShape.play(shape, )
    this.animations.get(shape.getName()).add(moveShape);
  }

  /**
   * This method is called upon by the EasyAnimatorModel object to change the color of an IShape
   * object from its current Color (r,g,b) to the new Color (r,g,b) passed in the argument for the
   * duration of the start and end time also passed in the argument. This method delegates the
   * changes to ChangeColor class that will mutate the color of IShape object passed in as the
   * argument.
   * @param shape The IShape object that we want to change the color of.
   * @param r The new Red color of the object.
   * @param g The new Green color of the object.
   * @param b The new Blue color of the object.
   * @param start The start time at which we want the change in color to start.
   * @param end The end time at which we want the change in color to end.
   * @throws IllegalArgumentException We throw this exception, when null is passed in instead of
   *                                  IShape object, when the start in the argument < IShape
   *                                  object's timeAppear, when the end time > IShape object's
   *                                  timeDisappear, when start > end.
   */
  public void changeColor(IShape shape, int r, int g, int b, double start,
                          double end) throws IllegalArgumentException {

    if(shape == null) {
      throw new NullPointerException("You can't pass a null shape");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException("Start time before shape appears or "
              + "end time after shape disappears.");
    }

    if (start > end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }

    AnimationChanges changeColor = new ChangeColor(new Color(r, g, b), shape,
            start, end);
    //changeColor.play(shape, )
    this.animations.get(shape.getName()).add(changeColor);
  }

  /**
   * This method is called upon by the EasyAnimatorModel object to change the scale of an IShape
   * object from its current size to the new size  passed in the argument  as the newLength and the
   * newWidth for the duration of the start and end time also passed in the argument. This method
   * delegates the changes to ScaleShape class that will mutate the scale of IShape object passed
   * in as the argument.
   * @param shape The IShape object that we want to change the scale of.
   * @param newLength The new length by which we want to increase the size of the IShape object.
   * @param newWidth The new width by which we want to increase the size of the IShape object.
   * @param start The start time at which we want the scale in color to start.
   * @param end The end time at which we want the scale in color to end.
   * @throws IllegalArgumentException We throw this exception, when null is passed in instead of
   *                                  IShape object, when the start in the argument < IShape
   *                                  object's timeAppear, when the end time > IShape object's
   *                                  timeDisappear, when start > end.
   */
  public void scaleShape(IShape shape, double newLength, double newWidth,
                         double start, double end) {
    if(shape == null) {
      throw new NullPointerException("You can't pass a null shape");
    }

    if (newLength < 0 || newWidth < 0) {
      throw new IllegalArgumentException("New length or width is negative.");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException("Start time before shape appears or "
              + "end time after shape disappears.");
    }

    if (start > end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }

    AnimationChanges scaleShape = new ScaleShape(newLength, newWidth, shape,
            start, end);
    //scaleShape.play(shape, )
    this.animations.get(shape.getName()).add(scaleShape);
  }

  /**
   * This method produces a text description of the animation. Tt first describes the shapes that
   * are part of the animation and their details. Next it describes how these shapes will move,
   * change color, change their scale, etc. as the animation proceeds from start to finish.
   * @return It returns a text description of hte animation.
   */
  public String toString() {
    String str = "Shapes:";
    for (IShape each : this.shapes) {
      str += each.toString();
    }

    str += "\n";

    List<ArrayList<String>> list= new ArrayList<>();
    int count = 0;

    for (String each : this.animations.keySet()) {
      for (AnimationChanges obj : this.animations.get(each)) {
        list.add(new ArrayList<>());
        list.get(count).add(Double.toString(obj.getStart()));
        list.get(count).add(obj.stringForm(each));
        count++;
      }
    }

    list.sort((o1, o2) -> {
      if (Double.parseDouble(o1.get(0)) < Double.parseDouble(o2.get(0))) return -1;
      if (Double.parseDouble(o1.get(0)) > Double.parseDouble(o2.get(0))) return 1;
      return 0;
    });

    for (ArrayList<String> subList : list) {
      str += subList.get(1);
    }
    return str;
  }

  /**
   * Getter method for hashMap.
   * @return Hashmap.
   */
  public HashMap<String, List<AnimationChanges>> getAnimations() {
    return this.animations;
  }


}
