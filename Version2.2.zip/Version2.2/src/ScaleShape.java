
public class ScaleShape implements AnimationChanges {
  private double newLength;
  private double newWidth;
  private double oldLength;
  private double oldWidth;
  private double start;
  private double end;

  public ScaleShape(double newLength, double newWidth, IShape shape, double start, double end) {
    this.newLength = newLength;
    this.newWidth = newWidth;
    this.oldLength = shape.getLength();
    this.oldWidth = shape.getWidth();
    this.start = start;
    this.end = end;
  }

  @Override
  public void executeChange(IShape shape, double time) {
    shape.setScale(newLength, newWidth);
  }

  @Override
  public String stringForm(String key) {
    String str;
    str = "Shape "
            + key
            + " scales from Width: "
            + oldLength
            + ", Height: "
            + oldWidth
            + " to Width: "
            + newLength
            + ", Height: "
            + newWidth
            + " from t="
            + String.format("%.0f", start)
            + " to t="
            + String.format("%.0f\n", end);
    return str;
  }

  @Override
  public double getStart() {
    return start;
  }
}
