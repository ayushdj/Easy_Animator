/**
 * This class represents the changes to the IShape object's size. It basically resizes the
 * IShape object from its current length and width  to the new length and width that is passed in to
 * initialize the ScaleShape object.
 */
public class ScaleShape implements AnimationChanges {
  private double newLength;
  private double newWidth;
  private double oldLength;
  private double oldWidth;
  private double start;
  private double end;

  /**
   * This constructor initializes the ScaleShape object. It takes in the new length and width
   * the IShape shape, and the start and end time that signify the duration of the
   * change in size.
   * @param newLength The new length of the IShape object.
   * @param newWidth The new width of the IShape object.
   * @param shape The IShape object that we want to change the size of
   * @param start The start time at which we want the movement to start.
   * @param end The end time at which we want the movement to end.
   * @throws IllegalArgumentException We throw this exception, when null is passed in instead of
   *                                  IShape object, when the start in the argument < IShape
   *                                  object's timeAppear, when the end time > IShape object's
   *                                  timeDisappear, when start > end.
   */
  public ScaleShape(double newLength, double newWidth, IShape shape, double start, double end) {


    if ( shape == null) {
      throw new IllegalArgumentException("Can't pass in null for the IShape object");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException("Start time before shape appears or "
              + "end time after shape disappears.");
    }

    if (start > end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }
    this.newLength = newLength;
    this.newWidth = newWidth;
    this.oldLength = shape.getLength();
    this.oldWidth = shape.getWidth();
    this.start = start;
    this.end = end;
  }

  /**
   * This method implements the mutation to the size of the IShape object. It changes the
   * current length and width of the IShape object to the new length and width.
   * @param shape The shape that we want to change the size of.
   * @param time The time stamp at which we want to see the reflected changes.
   */
  @Override
  public void executeChange(IShape shape, double time) {
    shape.setScale(newLength, newWidth);
  }

  /**
   * This method gives us the text representation of how the size of IShape changed. It identifies
   * the IShape object whose size we are changing by its name, its former size, and its new size.
   * @param key The name of the IShape object.
   * @return It returns a text representation of the change in size of our IShape object.
   */
  @Override
  public String stringForm(String key) {
    String str;
    str = "Shape "
            + key
            + " scales from Width: "
            + oldLength
            + ", Height: "
            + oldWidth
            + " to Width: "
            + newLength
            + ", Height: "
            + newWidth
            + " from t="
            + String.format("%.0f", start)
            + " to t="
            + String.format("%.0f\n", end);
    return str;
  }

  @Override
  public double getStart() {
    return start;
  }
}
