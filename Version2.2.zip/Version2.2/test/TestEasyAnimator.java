public class TestEasyAnimator {

  // rectangle r1
  // r1.accept(moveShape object, timeStamp)

  //EasyAnimatorimpl object
  //object.move(IShape shape, int newX, int newY, double start, double end)
}
