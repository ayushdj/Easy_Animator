import java.awt.*;

public class Driver {
  public static void main(String[] args) {
    IShape r1 = new Rectangle("R1", 0, 0, 4, 7, new Color(40, 50, 60), 0, 100);
    IShape c1 = new Oval("C1", 5, 5, 4, 4, new Color(40, 50, 60), 0, 100);
    IShape s1 = new Rectangle("S1", -3, -3, 4, 4, new Color(100, 150, 175), 48, 69);

    EasyAnimatorModel newAnimation = new EasyAnimatorModel();
    newAnimation.addShape(r1);
    newAnimation.addShape(c1);
    newAnimation.addShape(s1);

    newAnimation.moveShape(r1, 4, 8, 30, 60);
    newAnimation.changeColor(c1, 32, 45, 32, 10, 100);


    System.out.println(newAnimation.toString());
  }
}
