/**
 * This class tests the IShape Interface.
 */
public class TestIShape {
}
