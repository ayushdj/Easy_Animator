import org.junit.Before;
import org.junit.Test;

import java.awt.*;

import static org.junit.Assert.assertEquals;

/** This class tests the EasyAnimatorModel class. */
public class TestEasyAnimator {

  IShape rectangle1;
  IShape square1;
  IShape circle1;
  IShape oval1;
  EasyAnimatorModel newAnimation;

  @Before
  public void setUp() {
    rectangle1 = new Rectangle("R1", 0, 0, 4, 7, new Color(200, 100, 60), 10, 100);
    square1 = new Rectangle("S1", -3, -3, 4, 4, new Color(0, 100, 100), 30, 70);
    circle1 = new Oval("C1", 5, 5, 4, 4, new Color(40, 150, 60), 0, 100);
    oval1 = new Oval("O1", 2, 3, 7, 3, new Color(1, 15, 10), 50, 120);
    newAnimation = new EasyAnimatorModel();
  }

  /** Testing the case in which the shape added is null. */
  @Test(expected = NullPointerException.class)
  public void testIllegalAddShape1() {
    newAnimation.addShape(null);
  }

  /**
   * Testing the case in which we're adding a shape with the same key as another shape in the
   * hashmap.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalAddShape2() {
    newAnimation.addShape(rectangle1);
    IShape rectangle2 = new Rectangle("R1", 0, 1, 3, 1, new Color(50, 100, 255), 20, 30);
    newAnimation.addShape(rectangle2);
  }

  /**
   * Testing a valid addShape method.
   */
  @Test
  public void testAddShape() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    assertEquals(
            "Shapes:\n"
                    + "Name: R1\n"
                    + "Type: rectangle\n"
                    + "Min corner: (0.0,0.0), Width: 7.0, Height: 4.0, Color: (200.0,100.0,60.0)\n"
                    + "Appears at t=0.0\n"
                    + "Disappears at t=100.0\n"
                    + "\n"
                    + "Name: S1\n"
                    + "Type: rectangle\n"
                    + "Min corner: (-3.0,-3.0), Width: 4.0, Height: 4.0, Color: (50.0,100.0,255.0)\n"
                    + "Appears at t=48.0\n"
                    + "Disappears at t=69.0\n"
                    + "\n"
                    + "Name: C1\n"
                    + "Type: oval\n"
                    + "Min corner: (5.0,5.0), Width: 4.0, Height: 4.0, Color: (40.0,150.0,60.0)\n"
                    + "Appears at t=0.0\n"
                    + "Disappears at t=100.0\n"
                    + "\n"
                    + "Name: O1\n"
                    + "Type: oval\n"
                    + "Min corner: (3.0,3.0), Width: 3.0, Height: 7.0, Color: (1.0,15.0,10.0)\n"
                    + "Appears at t=50.0\n"
                    + "Disappears at t=120.0\n",
            newAnimation.toString());
  }

  // ===================================== MOVE-SHAPE TESTS ====================================
  /**
   * Testing the case in which the shape passed in is null.
   */
  @Test(expected = NullPointerException.class)
  public void testIllegalMoveShape1() {
    newAnimation.moveShape(null, 0, 0, 4, 5);
  }

  /**
   * Testing the case in which the start time is less than the shape's timeAppear, but the
   * end time is less than the shape's timeDisappear.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape2() {
    newAnimation.moveShape(rectangle1, 4,5, 5, 50);
  }

  /**
   * Testing the case in which the start time is greater than the timeAppear but the end time is
   * greater than the shape's timeDisappear.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape3() {
    newAnimation.moveShape(square1, 0, 0, 35, 75);
  }

  /**
   * Testing the case in which the start time is less than the timeAppear for the shape AND the end
   * time is greater than the shape's timeDisappear.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveShape4() {
    newAnimation.moveShape(oval1, 0, 0, 40, 130);
  }

  /**
   * Testing a legal moveShape.
   */
  @Test
  public void testLegalMoveShape() {
    newAnimation.addShape(rectangle1);
    newAnimation.addShape(square1);
    newAnimation.addShape(circle1);
    newAnimation.addShape(oval1);
    newAnimation.moveShape(rectangle1, 4, 8, 30, 60);
    newAnimation.moveShape(square1, 0, 0, 50, 60);
    newAnimation.moveShape(circle1, 0, 0, 20, 90);
    newAnimation.moveShape(oval1, 2, 2, 51, 100);
  }

  // ===================================== CHANGE-COLOR TESTS ==================================

  /**
   * Testing an illegal ColorChange where the shape passed in is null.
   */
  @Test(expected = NullPointerException.class)
  public void testIllegalChangeColor1() {
    newAnimation.changeColor(null, 0, 1, 2, 30, 50);
  }

}