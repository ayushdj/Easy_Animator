import org.junit.Before;
import org.junit.Test;

import java.awt.*;
import java.awt.geom.Point2D;

/**
 * This class tests the EasyAnimatorModel class.
 */
public class TestEasyAnimator {

    IShape shape1;
    IShape shape2;

    @Before
    public void init() {
      shape1 = new Rectangle("R1", 2.444, 5.32234, 10.12, 20,
              new Color(100, 200, 43), 2, 100);
      shape2 = new Oval("O1", 2, 5.1, 10.0, 20.003,
              new Color(100, 0, 43), 0, 50);
    }

  @Test(expected = NullPointerException.class)
  public void testInvalidMoveShape_NullShape() {
    new EasyAnimatorModel().moveShape(null, 4, 4, 10, 20);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveShape_StartTimeLessThanTimeAppear() {
    new EasyAnimatorModel().moveShape(shape1, 5, 5, 1, 10);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveShape_StartTimeGreaterThanTimeDisappear() {
    new EasyAnimatorModel().moveShape(shape1, 5, 5, 3, 101);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveShape_StartTimeGreaterThanEndTime() {
    new EasyAnimatorModel().moveShape(shape1, 5, 5, 50, 40);
  }

  @Test(expected = NullPointerException.class)
  public void testInvalidChangeColor_NullShape() {
    new EasyAnimatorModel().changeColor(null, 1, 1, 1, 5, 10);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidChangeColor_StartTimeLessThanTimeAppear() {
    new EasyAnimatorModel().changeColor(shape1, 1, 1, 1, 1, 10);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidChangeColor_StartTimeGreaterThanTimeDisappear() {
    new EasyAnimatorModel().changeColor(shape2, 1, 1, 1, 3, 101);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidChangeColor_StartTimeGreaterThanEndTime() {
    new EasyAnimatorModel().changeColor(shape2, 1, 1, 1, 50, 40);
  }

  @Test(expected = NullPointerException.class)
  public void testInvalidScaleShape_NullShape() {
    new EasyAnimatorModel().scaleShape(null, 2, 5, 10);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidScaleShape_StartTimeLessThanTimeAppear() {
    new EasyAnimatorModel().scaleShape(shape1, 3, 1, 10);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidScaleShape_StartTimeGreaterThanTimeDisappear() {
    new EasyAnimatorModel().scaleShape(shape2, 5, 3, 101);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidScaleShape_StartTimeGreaterThanEndTime() {
    new EasyAnimatorModel().scaleShape(shape2, 5, 50, 30);
  }

  @Test(expected = NullPointerException.class)
  public void testInvalidScaleShape_NullShape_1() {
    new EasyAnimatorModel().scaleShape(null, 2, 3, 5, 10);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidScaleShape_StartTimeLessThanTimeAppear_2() {
    new EasyAnimatorModel().scaleShape(shape1, 3, 4, 1, 10);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidScaleShape_StartTimeGreaterThanTimeDisappear_3() {
    new EasyAnimatorModel().scaleShape(shape2, 5, 6, 3, 101);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidScaleShape_StartTimeGreaterThanEndTime_4() {
    new EasyAnimatorModel().scaleShape(shape2, 5, 6, 50, 30);
  }
}
