import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This class is the Model of our animation. The model is responsible for implementing the logic
 * that updates the state of objects to eventually pass that information to the controller. Our
 * EasyAnimatorModel model implements the logic to change the state of IShape objects to represent
 * animations on them.
 */
public class EasyAnimatorModelImpl implements EasyAnimatorModel {

  // This is a list of original states our all of our shapes in the animation
  private List<IShape> shapes;

  // Key(String) and value = list of all the mutations that take place on that particular object
  // clones of the original object during a particular time interval.
  private HashMap<String, List<AnimationChanges>> animations;

  public EasyAnimatorModelImpl() {
    this.shapes = new ArrayList();
    this.animations = new HashMap();
  }

  @Override
  public void addShape(IShape shape) throws IllegalArgumentException {
    if (shape == null) {
      throw new IllegalArgumentException("You can't pass a null shape");
    }

    if (animations.containsKey(shape.getName())) {
      throw new IllegalArgumentException("This key already exists");
    }

    this.shapes.add(shape);
    IShape clonedShape = shape.cloneShape();
    this.animations.put(clonedShape.getName(), new ArrayList());
  }

  @Override
  public void removeShape(IShape shape) throws IllegalArgumentException {
    if (shape == null) {
      throw new IllegalArgumentException("You can't pass a null shape");
    }

    if (!animations.containsKey(shape.getName())) {
      throw new IllegalArgumentException("This key doesn't exist.");
    }

    this.animations.remove(shape.getName());
    shapes.removeIf(each -> each.getName().equalsIgnoreCase(shape.getName()));
  }

  @Override
  public void moveShape(IShape shape, int newX, int newY, double start, double end)
      throws IllegalArgumentException {
    if (shape == null) {
      throw new IllegalArgumentException("You can't pass a null shape");
    }
    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException(
          "Start time before shape appears or " + "end time after shape disappears.");
    }
    if (start >= end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }

    if (newX == shape.getX() && newY == shape.getY()) {
      return;
    }

    AnimationChanges moveShape = new MoveShape(new Point2D.Double(newX, newY), shape, start, end);
    double duration = end - start;
    moveShape.executeChange(shape, duration);
    this.animations.get(shape.getName()).add(moveShape);
  }

  @Override
  public void changeColor(IShape shape, int r, int g, int b, double start, double end)
      throws IllegalArgumentException {
    if (shape == null) {
      throw new IllegalArgumentException("You can't pass a null shape");
    }
    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException(
          "Start time before shape appears or " + "end time after shape disappears.");
    }
    if (start >= end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }
    if (r == shape.getColor().getRed()
        && g == shape.getColor().getGreen()
        && b == shape.getColor().getBlue()) {
      return;
    }
    if (r < 0 || g < 0 || b < 0 || r > 255 || g > 255 || b > 255) {
      throw new IllegalArgumentException("color values out of bounds");
    }

    AnimationChanges changeColor = new ChangeColor(new Color(r, g, b), shape, start, end);
    changeColor.executeChange(shape, end - start);
    this.animations.get(shape.getName()).add(changeColor);
  }

  @Override
  public void scaleShape(IShape shape, double scaleFactor, double start, double end)
      throws IllegalArgumentException {
    if (shape == null) {
      throw new IllegalArgumentException("You can't pass a null shape");
    }

    if (scaleFactor < 0) {
      throw new IllegalArgumentException("Scale factor is negative, cannot be negative.");
    }

    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException(
          "Start time before shape appears or " + "end time after shape disappears.");
    }
    if (start >= end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }
    if (scaleFactor == 1.0) {
      return;
    }
    AnimationChanges scaledShape = new ScaleShape(scaleFactor, shape, start, end);
    double duration = end - start;
    scaledShape.executeChange(shape, duration);
    this.animations.get(shape.getName()).add(scaledShape);
  }

  @Override
  public void scaleShape(IShape shape, double newLength, double newWidth, double start, double end)
      throws IllegalArgumentException {
    if (shape == null) {
      throw new IllegalArgumentException("You can't pass a null shape");
    }
    if (newLength <= 0 || newWidth <= 0) {
      throw new IllegalArgumentException("Length or width is negative or 0, cannot be negative.");
    }
    if (start < shape.getTimeAppear() || end > shape.getTimeDisappear()) {
      throw new IllegalArgumentException(
          "Start time before shape appears or " + "end time after shape disappears.");
    }
    if (start >= end) {
      throw new IllegalArgumentException("Start is greater than end.");
    }

    if (newLength == shape.getLength() && newWidth == shape.getWidth()) {
      return;
    }

    AnimationChanges scaledShape = new ScaleShape(newLength, newWidth, shape, start, end);
    double duration = end - start;
    scaledShape.executeChange(shape, duration);
    this.animations.get(shape.getName()).add(scaledShape);
  }

  @Override
  public String toString() {
    String str = "Shapes:";
    for (IShape each : this.shapes) {
      str += each.toString();
    }

    str += "\n";

    List<ArrayList<String>> list = new ArrayList<>();
    int count = 0;

    for (String each : this.animations.keySet()) {
      for (AnimationChanges obj : this.animations.get(each)) {
        list.add(new ArrayList<>());
        list.get(count).add(Double.toString(obj.getStart()));
        list.get(count).add(obj.stringForm(each));
        count++;
      }
    }

    list.sort(
        (o1, o2) -> {
          if (Double.parseDouble(o1.get(0)) < Double.parseDouble(o2.get(0))) return -1;
          if (Double.parseDouble(o1.get(0)) > Double.parseDouble(o2.get(0))) return 1;
          return 0;
        });

    for (ArrayList<String> subList : list) {
      str += subList.get(1);
    }
    return str;
  }

  @Override
  public HashMap<String, List<AnimationChanges>> getAnimations() {
    return this.animations;
  }

  @Override
  public List<IShape> getShapesAtTimeStamp(double time) {
    //List<IShape>
    return null;
  }

  @Override
  public String showShapeJourney(String name) {
    if (name == null) {
      throw new IllegalArgumentException("name is null, can't be null");
    }
    String str = "";
    for (IShape shape : this.shapes) {
      if (shape.getName().equalsIgnoreCase(name)) {
        str += shape.toString();
        break;
      }
    }
    if (str.isEmpty()) {
      throw new IllegalArgumentException("The shape doesn't exist");
    }
    List<AnimationChanges> listOfChanges = this.animations.get(name);
    for (AnimationChanges each : listOfChanges) {
      str += each.stringForm(name);
    }
    return str;
  }

  @Override
  public String showShapeJourney(IShape shape) {
    if (shape == null) {
      throw new IllegalArgumentException("Shape is null, can't be null");
    }
    String str = "";
    for (IShape each : this.shapes) {
      if (each.getName().equalsIgnoreCase(shape.getName())) {
        str += each.toString();
        break;
      }
    }
    if (str.isEmpty()) {
      throw new IllegalArgumentException("The shape doesn't exist");
    }
    List<AnimationChanges> listOfChanges = this.animations.get(shape.getName());
    for (AnimationChanges each : listOfChanges) {
      str += each.stringForm(shape.getName());
    }
    return str;
  }
}
