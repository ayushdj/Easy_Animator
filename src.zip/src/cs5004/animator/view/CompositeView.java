package cs5004.animator.view;
import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.*;

import cs5004.animator.model.EasyAnimatorModel;

/**
 * This class represents a composite view. This is such that if a user type's in
 * "playback" in their command line arguments, an interactive GUI is generated. This
 * class represents that interactive GUI.
 */
public class CompositeView implements IView{

  private CompositeFrame frame;
  private EasyAnimatorModel model;

  /**
   * Generates a composite view instance.
   *
   * @param model The model whose data structures have been populated using the builder.
   */
  public CompositeView(EasyAnimatorModel model){
    this.model = model;
    this.frame = new CompositeFrame(model.getX(), model.getY(),
            model.getCanvasWidth(), model.getCanvasHeight(), model.getShapes());
  }


  /**
   * We are adding
   * @param listenForStart
   */
  public void addStartListener(ActionListener listenForStart) {

    //this.frame.getStartButton().setBorder(BorderFactory.createLineBorder(Color.green));

    this.frame.getStartButton().addActionListener(listenForStart);

  }

  public void addPauseListener(ActionListener listenForPause) {

    this.frame.getPauseButton().addActionListener(listenForPause);

  }

  public void addRestartListener(ActionListener listenForRestart) {

    this.frame.getRestartButton().addActionListener(listenForRestart);

  }

  public void addSpeedUpListener(ActionListener listenForSpeedUp) {

    this.frame.getSpeedUpButton().addActionListener(listenForSpeedUp);

  }

  public void addSlowDownListener(ActionListener listenForSlowDown) {

    this.frame.getSlowDownButton().addActionListener(listenForSlowDown);

  }

  public void addLoopListener(ActionListener listenForLoop) {

    this.frame.getLoopButton().addActionListener(listenForLoop);

  }

  public void addResumeListener(ActionListener listenForResume) {

    this.frame.getResumeButton().addActionListener(listenForResume);

  }

  public void addMenuItemListener(ActionListener listenForNewFile) {
    this.frame.getMenuItem().addActionListener(listenForNewFile);
  }

  /** ADDED 3 BELOW METHODS
  public void addRemoveShapeListener(ActionListener listenForRemoveShape) {
    this.frame.getRemoveShape().addActionListener(listenForRemoveShape);
  }

  public void addSaveTextListener(ActionListener listenForSaveText) {
    this.frame.getSaveText().addActionListener(listenForSaveText);
  }

  public void addSaveSvgListener(ActionListener listenForSaveSvg) {
    this.frame.getSaveSvg().addActionListener(listenForSaveSvg);
  }
*/

  @Override
  public String getViewType() {
    return "playback";
  }

  @Override
  public String showView() {
    return null;
  }

  @Override
  public SwingFrame getFrame() {
    return null;
  }

  public CompositeFrame getCompositeFrame() {
    return this.frame;
  }

  @Override
  public String getOutputFile() {
    return null;
  }


}
