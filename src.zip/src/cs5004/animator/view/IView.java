package cs5004.animator.view;

import java.awt.event.ActionListener;

/**
 * This interface represents a type of view. There are 3 types of views we want to implement for the
 * project: A TextView, SVGView and a VisualView.
 */
public interface IView {

  /**
   * A getter method to return the type of animation we are working with.
   *
   * @return A String representation of the type of view we are working with.
   */
  String getViewType();

  /**
   * This method shows the view to the user.
   *
   * @return A string representation of the model.
   */
  String showView();

  /**
   * This method is a getter method to return the frame for the visual view. For the text
   * and the SvgView, it returns NULL.
   *
   * @return the SwingFrame, so that the current view can be called.
   */
  SwingFrame getFrame();

  CompositeFrame getCompositeFrame();

  public String getOutputFile();

  void addStartListener(ActionListener listenForStart);

  void addPauseListener(ActionListener listenForPause);

  void addRestartListener(ActionListener listenForRestart);

  void addSpeedUpListener(ActionListener listenForSpeedUp);

  void addSlowDownListener(ActionListener listenForSlowDown);

  void addLoopListener(ActionListener listenForLoop);

  void addResumeListener(ActionListener listenForResume);

  void addMenuItemListener(ActionListener listenForNewFile);

  void addRemoveShapeListener(ActionListener removeShapeListener);

  void addSaveTextListener(ActionListener saveTextListener);

  void addSaveSvgListener(ActionListener saveSvgListener);

}
